[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

$scriptDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
$transactionScript = Join-Path $scriptDirectory 'Installer.Transaction.ps1'
if (-not (Test-Path -LiteralPath $transactionScript -PathType Leaf)) {
    throw 'The package is missing Installer.Transaction.ps1.'
}
. $transactionScript

$runningExcel = Get-Process -Name EXCEL -ErrorAction SilentlyContinue
if ($runningExcel) {
    throw 'Close every Excel window before uninstalling Lineage. The uninstaller will not close workbooks automatically.'
}

$localAppData = [Environment]::GetFolderPath(
    [Environment+SpecialFolder]::LocalApplicationData)
if ([string]::IsNullOrWhiteSpace($localAppData)) {
    throw 'The current Windows profile does not expose a Local AppData directory.'
}
$installDirectory = [System.IO.Path]::GetFullPath((Join-Path $localAppData 'Lineage'))
$targetPath = Join-Path $installDirectory 'Lineage.xll'
$optionsPath = 'HKCU:\Software\Microsoft\Office\16.0\Excel\Options'
$trustedLocationPath = 'HKCU:\Software\Microsoft\Office\16.0\Excel\Security\Trusted Locations\LineageNative'
$installDirectoryExisted = Test-Path -LiteralPath $installDirectory -PathType Container
$receiptPath = Join-Path $installDirectory 'install.json'
$trustedInstallPath = $installDirectory + '\'
$packageVersionPath = Join-Path $scriptDirectory 'version.txt'
$distributionChannelPath = Join-Path $scriptDirectory 'distribution-channel.txt'

if (-not (Test-Path -LiteralPath $packageVersionPath -PathType Leaf)) {
    throw 'The package is missing version.txt.'
}
if (-not (Test-Path -LiteralPath $distributionChannelPath -PathType Leaf)) {
    throw 'The package is missing distribution-channel.txt.'
}
$packageVersion = (Get-Content -LiteralPath $packageVersionPath -Raw).Trim()
Assert-LineagePackageVersionSupported -PackageVersion $packageVersion
$packageDistributionChannel = Resolve-LineagePackageDistributionChannel `
    -Value (Get-Content -LiteralPath $distributionChannelPath -Raw)

Assert-LineageDirectorySafeOrMissing -Path $installDirectory -Label 'The Lineage install directory'
Assert-LineageLeafOrMissing -Path $targetPath -Label 'The Lineage XLL target'
Assert-LineageLeafOrMissing -Path $receiptPath -Label 'The Lineage receipt target'

$receipt = $null
if (Test-Path -LiteralPath $receiptPath -PathType Leaf) {
    try {
        $receipt = Get-Content -LiteralPath $receiptPath -Raw | ConvertFrom-Json
    }
    catch {
        throw "The Lineage install receipt is invalid: $($_.Exception.Message)"
    }
}
$receiptRegistrationName = if ($null -ne $receipt -and
    $null -ne $receipt.PSObject.Properties['registrationValue'] -and
    [string]$receipt.registrationValue -match '^OPEN\d*$') {
    [string]$receipt.registrationValue
}
else {
    $null
}
$exactRegistrationNames = @()
if (Test-Path -LiteralPath $optionsPath) {
    $optionsKey = Get-Item -LiteralPath $optionsPath
    foreach ($valueName in @($optionsKey.GetValueNames() | Where-Object { $_ -match '^OPEN\d*$' })) {
        $value = $optionsKey.GetValue(
            $valueName,
            $null,
            [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
        if (Test-LineageOpenRegistration -Value ([string]$value) -TargetPath $targetPath) {
            $exactRegistrationNames += $valueName
        }
    }
}
$registrationName = if (-not [string]::IsNullOrWhiteSpace($receiptRegistrationName)) {
    $receiptRegistrationName
}
elseif ($exactRegistrationNames.Count -gt 0) {
    [string]$exactRegistrationNames[0]
}
else {
    'OPEN'
}
$registrationSnapshot = Get-LineageRegistryValueSnapshot -Path $optionsPath -Name $registrationName
$trustedPathSnapshot = Get-LineageRegistryValueSnapshot -Path $trustedLocationPath -Name 'Path'
$trustedSubfoldersSnapshot = Get-LineageRegistryValueSnapshot -Path $trustedLocationPath -Name 'AllowSubfolders'
$trustedDescriptionSnapshot = Get-LineageRegistryValueSnapshot -Path $trustedLocationPath -Name 'Description'
$trustedPathExisted = Test-Path -LiteralPath $trustedLocationPath
$trustedValueNames = if ($trustedPathExisted) {
    @((Get-Item -LiteralPath $trustedLocationPath).GetValueNames())
}
else {
    @()
}
$installDirectoryItems = if ($installDirectoryExisted) {
    @(Get-ChildItem -LiteralPath $installDirectory -Force)
}
else {
    @()
}
$installedXllHash = if (Test-Path -LiteralPath $targetPath -PathType Leaf) {
    (Get-FileHash -LiteralPath $targetPath -Algorithm SHA256).Hash
}
else {
    $null
}
$ownershipPlatform = if ($null -ne $receipt -and
    $null -ne $receipt.PSObject.Properties['excelArchitecture'] -and
    [string]$receipt.excelArchitecture -in @('x64', 'x86')) {
    [string]$receipt.excelArchitecture
}
else {
    'x64'
}
$ownershipVerified = Test-LineageInstallationOwnership `
    -Receipt $receipt `
    -TargetPath $targetPath `
    -PackageVersion $packageVersion `
    -Platform $ownershipPlatform `
    -InstalledXllHash $installedXllHash `
    -RegistrationValueName $registrationName `
    -RegistrationSnapshot $registrationSnapshot `
    -TrustedPathSnapshot $trustedPathSnapshot `
    -TrustedSubfoldersSnapshot $trustedSubfoldersSnapshot `
    -TrustedDescriptionSnapshot $trustedDescriptionSnapshot `
    -TrustedValueNames $trustedValueNames `
    -ExpectedTrustedPath $trustedInstallPath `
    -InstallDirectoryItems $installDirectoryItems
$managedStateExists = Test-LineageManagedStateExists `
    -TargetExists (Test-Path -LiteralPath $targetPath) `
    -ReceiptExists (Test-Path -LiteralPath $receiptPath) `
    -ExactRegistrationFound ($exactRegistrationNames.Count -gt 0) `
    -TrustedPathExists $trustedPathExisted `
    -InstallDirectoryItems $installDirectoryItems
Assert-LineageDistributionChannelTransition `
    -IncomingChannel $packageDistributionChannel `
    -ManagedStateExists $managedStateExists `
    -ExistingReceipt $receipt
Assert-LineageUninstallStateOwned `
    -ManagedStateExists $managedStateExists `
    -OwnershipVerified $ownershipVerified
if (-not $managedStateExists) {
    Write-Output 'Lineage is not installed; no owned state was removed.'
    return
}

$registrationSnapshots = @(
    New-LineageOwnedRegistryValueSnapshot `
        -Name $registrationName `
        -Value $registrationSnapshot.Value `
        -Kind $registrationSnapshot.Kind
)
$trustedLocationOwned = $true
$trustedValueSnapshots = @(
    [pscustomobject]@{
        Name = 'Path'
        Exists = $trustedPathSnapshot.Exists
        Value = $trustedPathSnapshot.Value
        Kind = $trustedPathSnapshot.Kind
    }
    [pscustomobject]@{
        Name = 'AllowSubfolders'
        Exists = $trustedSubfoldersSnapshot.Exists
        Value = $trustedSubfoldersSnapshot.Value
        Kind = $trustedSubfoldersSnapshot.Kind
    }
    [pscustomobject]@{
        Name = 'Description'
        Exists = $trustedDescriptionSnapshot.Exists
        Value = $trustedDescriptionSnapshot.Value
        Kind = $trustedDescriptionSnapshot.Kind
    }
)

$backupDirectory = Join-Path ([System.IO.Path]::GetTempPath()) ('LineageUninstall-' + [Guid]::NewGuid().ToString('N'))
[void](New-Item -ItemType Directory -Path $backupDirectory)
$fileSnapshots = $null
try {
    $fileSnapshots = @(
        foreach ($fileName in @('Lineage.xll', 'Lineage.log', 'install.json')) {
            $filePath = Join-Path $installDirectory $fileName
            $backupPath = Join-Path $backupDirectory $fileName
            $exists = Test-Path -LiteralPath $filePath -PathType Leaf
            if ($exists) {
                Copy-Item -LiteralPath $filePath -Destination $backupPath
            }
            $fileHash = if ($exists) {
                (Get-FileHash -LiteralPath $filePath -Algorithm SHA256).Hash
            }
            else {
                $null
            }
            if ($exists -and -not [string]::Equals(
                $fileHash,
                (Get-FileHash -LiteralPath $backupPath -Algorithm SHA256).Hash,
                [StringComparison]::OrdinalIgnoreCase)) {
                throw "The uninstall backup differs from its owned source: $filePath"
            }
            [pscustomobject]@{
                Path = $filePath
                BackupPath = $backupPath
                Exists = $exists
                Hash = $fileHash
            }
        }
    )
}
catch {
    if (Test-Path -LiteralPath $backupDirectory -PathType Container) {
        Remove-Item -LiteralPath $backupDirectory -Recurse -Force -ErrorAction SilentlyContinue
    }
    throw
}

$steps = @(
    New-LineageOwnedRegistryRemovalStep `
        -Name 'Remove Excel registration' `
        -Path $optionsPath `
        -ValueSnapshots $registrationSnapshots `
        -OwnershipVerified ($registrationSnapshots.Count -gt 0)
    New-LineageOwnedRegistryRemovalStep `
        -Name 'Remove trusted location' `
        -Path $trustedLocationPath `
        -ValueSnapshots $trustedValueSnapshots `
        -OwnershipVerified $trustedLocationOwned `
        -RemovePathWhenEmpty
    New-LineageOwnedFileRemovalStep `
        -Name 'Remove receipt-owned installed files' `
        -FileSnapshots @($fileSnapshots | Where-Object { $_.Exists })
    New-LineageTransactionStep -Name 'Remove empty install directory' -Apply {
        if (Test-Path -LiteralPath $installDirectory -PathType Container) {
            $remaining = @(Get-ChildItem -LiteralPath $installDirectory -Force)
            if ($remaining.Count -eq 0) {
                Remove-Item -LiteralPath $installDirectory -Force
            }
        }
    } -Rollback {
        if ($installDirectoryExisted -and
            -not (Test-Path -LiteralPath $installDirectory -PathType Container)) {
            [void](New-Item -ItemType Directory -Path $installDirectory)
        }
    }
)

$rollbackIncomplete = $false
try {
    Invoke-LineageTransaction -Steps $steps
}
catch {
    if ($_.Exception.Data['LineageRollbackIncomplete'] -eq $true) {
        $rollbackIncomplete = $true
        $message = $_.Exception.Message +
            " Recovery backups were preserved at $backupDirectory."
        throw [InvalidOperationException]::new($message, $_.Exception)
    }
    throw
}
finally {
    if (-not $rollbackIncomplete) {
        Remove-Item -LiteralPath $backupDirectory -Recurse -Force -ErrorAction SilentlyContinue
    }
}

Write-Output 'Lineage was transactionally uninstalled. Only unchanged, fully verified receipt-owned files and registry values were removed.'
