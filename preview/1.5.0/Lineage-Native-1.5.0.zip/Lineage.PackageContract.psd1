@{
    SchemaVersion = 2

    PackageFiles = @(
        'Install-Lineage.ps1'
        'Installer.Transaction.ps1'
        'Lineage.PackageCatalog.psd1'
        'Lineage.PackageContract.psd1'
        'Lineage.Signature.Validation.ps1'
        'Lineage32.xll'
        'Lineage64.xll'
        'distribution-channel.txt'
        'manifest.sha256'
        'README.txt'
        'Uninstall-Lineage.ps1'
        'version.txt'
    )

    InstallerFiles = @(
        'Install-Lineage.ps1'
        'Installer.Transaction.ps1'
        'Lineage.PackageContract.psd1'
        'Lineage.Signature.Validation.ps1'
        'Uninstall-Lineage.ps1'
    )

    SignedPayloadFiles = @(
        'Install-Lineage.ps1'
        'Installer.Transaction.ps1'
        'Lineage.PackageContract.psd1'
        'Lineage.Signature.Validation.ps1'
        'Lineage32.xll'
        'Lineage64.xll'
        'Uninstall-Lineage.ps1'
    )

    RequiredReadmeText = @(
        'Trace'
        'Lineage Settings'
        'background commands'
        'one-level undo'
        'separately distributed signed bootstrap'
    )

    ForbiddenReadmeText = @(
        'import'
        'export'
        'Paste Special'
        'Return to Origin'
        'Jump To'
        'New Window'
        'Toggle R1C1'
        'Zoom To'
    )
}
