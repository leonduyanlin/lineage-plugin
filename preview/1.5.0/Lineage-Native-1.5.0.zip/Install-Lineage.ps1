[CmdletBinding()]
param(
    [string]$PackageDirectory = $PSScriptRoot,
    [switch]$SkipLaunch
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
Set-StrictMode -Version 2.0

$scriptDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
$transactionScript = Join-Path $scriptDirectory 'Installer.Transaction.ps1'
if (-not (Test-Path -LiteralPath $transactionScript -PathType Leaf)) {
    throw 'The package is missing Installer.Transaction.ps1.'
}
. $transactionScript

if ([string]::IsNullOrWhiteSpace($PackageDirectory)) {
    $PackageDirectory = $scriptDirectory
}
if ([string]::IsNullOrWhiteSpace($PackageDirectory)) {
    throw 'The Lineage package directory could not be resolved.'
}
$PackageDirectory = [System.IO.Path]::GetFullPath($PackageDirectory)

$runningExcel = Get-Process -Name EXCEL -ErrorAction SilentlyContinue
if ($runningExcel) {
    throw 'Close every Excel window before installing Lineage. The installer will not close workbooks automatically.'
}

$clickToRunPath = 'HKLM:\SOFTWARE\Microsoft\Office\ClickToRun\Configuration'
$platform = if (Test-Path -LiteralPath $clickToRunPath) {
    [string](Get-ItemPropertyValue -LiteralPath $clickToRunPath -Name 'Platform')
}
elseif (Test-Path -LiteralPath 'C:\Program Files\Microsoft Office\Root\Office16\EXCEL.EXE') {
    'x64'
}
elseif (Test-Path -LiteralPath 'C:\Program Files (x86)\Microsoft Office\Root\Office16\EXCEL.EXE') {
    'x86'
}
else {
    throw 'Excel was not found on this computer.'
}
if ($platform -notin @('x64', 'x86')) {
    throw "Excel reported unsupported architecture '$platform'."
}

$sourceName = if ($platform -eq 'x64') { 'Lineage64.xll' } else { 'Lineage32.xll' }
$sourcePath = Join-Path $PackageDirectory $sourceName
if (-not (Test-Path -LiteralPath $sourcePath -PathType Leaf)) {
    throw "The package is missing $sourceName."
}

$manifestPath = Join-Path $PackageDirectory 'manifest.sha256'
if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) {
    throw 'The package is missing manifest.sha256.'
}
$manifestEntries = Get-LineageManifestEntries `
    -Lines @(Get-Content -LiteralPath $manifestPath)
Assert-LineagePackagePayloadIntegrity `
    -PackageDirectory $PackageDirectory `
    -ManifestEntries $manifestEntries
if (-not $manifestEntries.ContainsKey($sourceName)) {
    throw "The package manifest does not contain $sourceName."
}
$expectedHash = $manifestEntries[$sourceName]
$actualHash = (Get-FileHash -LiteralPath $sourcePath -Algorithm SHA256).Hash
if ($actualHash -ne $expectedHash) {
    throw "$sourceName failed package integrity verification."
}

$versionPath = Join-Path $PackageDirectory 'version.txt'
if (-not (Test-Path -LiteralPath $versionPath -PathType Leaf)) {
    throw 'The package is missing version.txt.'
}
if (-not $manifestEntries.ContainsKey('version.txt')) {
    throw 'The package manifest does not contain version.txt.'
}
$versionSnapshot = Get-LineageVerifiedUtf8TextSnapshot `
    -Path $versionPath `
    -ExpectedHash $manifestEntries['version.txt']
$packageVersion = $versionSnapshot.Text.Trim()
Assert-LineagePackageVersionSupported -PackageVersion $packageVersion
$distributionChannelPath = Join-Path $PackageDirectory 'distribution-channel.txt'
if (-not $manifestEntries.ContainsKey('distribution-channel.txt')) {
    throw 'The package manifest does not contain distribution-channel.txt.'
}
$distributionChannelSnapshot = Get-LineageVerifiedUtf8TextSnapshot `
    -Path $distributionChannelPath `
    -ExpectedHash $manifestEntries['distribution-channel.txt']
$packageDistributionChannel = Resolve-LineagePackageDistributionChannel `
    -Value $distributionChannelSnapshot.Text

$localAppData = [Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData)
if ([string]::IsNullOrWhiteSpace($localAppData)) {
    throw 'The current Windows profile does not expose a Local AppData directory.'
}
$installDirectory = Join-Path $localAppData 'Lineage'
$targetPath = Join-Path $installDirectory 'Lineage.xll'
$receiptPath = Join-Path $installDirectory 'install.json'
$trustedLocationPath = 'HKCU:\Software\Microsoft\Office\16.0\Excel\Security\Trusted Locations\LineageNative'
$optionsPath = 'HKCU:\Software\Microsoft\Office\16.0\Excel\Options'
$trustedInstallPath = $installDirectory + '\'

# Reject path-type collisions before creating backups or mutating any state.
Assert-LineageDirectorySafeOrMissing -Path $installDirectory -Label 'The Lineage install directory'
Assert-LineageLeafOrMissing -Path $targetPath -Label 'The Lineage XLL target'
Assert-LineageLeafOrMissing -Path $receiptPath -Label 'The Lineage receipt target'
$priorReceipt = $null
if (Test-Path -LiteralPath $receiptPath -PathType Leaf) {
    try {
        $priorReceiptSnapshot = Get-LineageJsonFileSnapshot -Path $receiptPath
        $priorReceipt = $priorReceiptSnapshot.Value
    }
    catch {
        throw "The existing Lineage install receipt is invalid: $($_.Exception.Message)"
    }
}
# Complete registry-slot discovery before the first installation write.
$optionsPathExisted = Test-Path -LiteralPath $optionsPath
$openValueNames = @()
if ($optionsPathExisted) {
    $optionsKey = Get-Item -LiteralPath $optionsPath
    $openValueNames = @($optionsKey.GetValueNames() | Where-Object { $_ -match '^OPEN\d*$' })
}
$registrationValueName = $null
$exactRegistrationFound = $false
foreach ($valueName in $openValueNames) {
    $value = $optionsKey.GetValue(
        $valueName,
        $null,
        [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
    if (Test-LineageOpenRegistration -Value ([string]$value) -TargetPath $targetPath) {
        $registrationValueName = $valueName
        $exactRegistrationFound = $true
        break
    }
}
if ($null -eq $registrationValueName) {
    for ($index = 0; $index -lt 100; $index++) {
        $candidateName = if ($index -eq 0) { 'OPEN' } else { "OPEN$index" }
        if ($openValueNames -notcontains $candidateName) {
            $registrationValueName = $candidateName
            break
        }
    }
}
if ($null -eq $registrationValueName) {
    throw 'Excel has no available OPEN registration slot.'
}

$registrationSnapshot = Get-LineageRegistryValueSnapshot -Path $optionsPath -Name $registrationValueName
$trustedPathExisted = Test-Path -LiteralPath $trustedLocationPath
$trustedPathSnapshot = Get-LineageRegistryValueSnapshot -Path $trustedLocationPath -Name 'Path'
$trustedSubfoldersSnapshot = Get-LineageRegistryValueSnapshot -Path $trustedLocationPath -Name 'AllowSubfolders'
$trustedDescriptionSnapshot = Get-LineageRegistryValueSnapshot -Path $trustedLocationPath -Name 'Description'
$trustedValueNames = if ($trustedPathExisted) {
    @((Get-Item -LiteralPath $trustedLocationPath).GetValueNames())
}
else {
    @()
}
$installedXllHash = if (Test-Path -LiteralPath $targetPath -PathType Leaf) {
    (Get-FileHash -LiteralPath $targetPath -Algorithm SHA256).Hash
}
else {
    $null
}
$existingReceiptHash = if (Test-Path -LiteralPath $receiptPath -PathType Leaf) {
    $priorReceiptSnapshot.Hash
}
else {
    $null
}
$installDirectoryItems = if (Test-Path -LiteralPath $installDirectory -PathType Container) {
    @(Get-ChildItem -LiteralPath $installDirectory -Force)
}
else {
    @()
}
$priorInstallationOwned = Test-LineageInstallationOwnership `
    -Receipt $priorReceipt `
    -TargetPath $targetPath `
    -PackageVersion $packageVersion `
    -Platform $platform `
    -InstalledXllHash $installedXllHash `
    -RegistrationValueName $registrationValueName `
    -RegistrationSnapshot $registrationSnapshot `
    -TrustedPathSnapshot $trustedPathSnapshot `
    -TrustedSubfoldersSnapshot $trustedSubfoldersSnapshot `
    -TrustedDescriptionSnapshot $trustedDescriptionSnapshot `
    -TrustedValueNames $trustedValueNames `
    -ExpectedTrustedPath $trustedInstallPath `
    -InstallDirectoryItems $installDirectoryItems
$managedStateExists = Test-LineageManagedStateExists `
    -TargetExists (Test-Path -LiteralPath $targetPath) `
    -ReceiptExists (Test-Path -LiteralPath $receiptPath) `
    -ExactRegistrationFound $exactRegistrationFound `
    -TrustedPathExists $trustedPathExisted `
    -InstallDirectoryItems $installDirectoryItems
Assert-LineageDistributionChannelTransition `
    -IncomingChannel $packageDistributionChannel `
    -ManagedStateExists $managedStateExists `
    -ExistingReceipt $priorReceipt
$legacy121ReceiptPresent = $null -ne $priorReceipt -and
    $null -ne $priorReceipt.PSObject.Properties['version'] -and
    [string]$priorReceipt.version -ceq '1.2.1'
Assert-LineageExistingManagedStateOwned `
    -ManagedStateExists $managedStateExists `
    -OwnershipVerified $priorInstallationOwned `
    -Legacy121ReceiptPresent:$legacy121ReceiptPresent
Assert-LineageTrustedLocationCompatible `
    -PathSnapshot $trustedPathSnapshot `
    -AllowSubfoldersSnapshot $trustedSubfoldersSnapshot `
    -DescriptionSnapshot $trustedDescriptionSnapshot `
    -ExpectedPath $trustedInstallPath `
    -PriorInstallationOwned $priorInstallationOwned
$installDirectoryExisted = Test-Path -LiteralPath $installDirectory -PathType Container
$targetExisted = Test-Path -LiteralPath $targetPath -PathType Leaf
$receiptExisted = Test-Path -LiteralPath $receiptPath -PathType Leaf

$backupDirectory = Join-Path ([System.IO.Path]::GetTempPath()) ('LineageInstall-' + [Guid]::NewGuid().ToString('N'))
[void](New-Item -ItemType Directory -Path $backupDirectory)
$targetBackup = Join-Path $backupDirectory 'Lineage.xll'
$receiptBackup = Join-Path $backupDirectory 'install.json'
$targetStaging = Join-Path $installDirectory ('Lineage.xll.new-' + [Guid]::NewGuid().ToString('N'))
$receiptStaging = Join-Path $installDirectory ('install.json.new-' + [Guid]::NewGuid().ToString('N'))
$registrationCommand = Get-LineageRegistrationCommand -TargetPath $targetPath

$receipt = [ordered]@{
    version = $packageVersion
    distributionChannel = $packageDistributionChannel
    installedAt = [DateTimeOffset]::Now.ToString('O')
    excelArchitecture = $platform
    xll = $targetPath
    sha256 = $actualHash
    registrationValue = $registrationValueName
    registrationCommand = $registrationCommand
}
$preInstallDirectoryNames = @($installDirectoryItems | ForEach-Object { $_.Name })
$postXllDirectoryNames = @($preInstallDirectoryNames)
if (-not $targetExisted) {
    $postXllDirectoryNames += (Split-Path $targetPath -Leaf)
}
$assertInstalledStateCommitReady = ${function:Assert-LineageInstalledStateCommitReady}
$getRegistryValueSnapshot = ${function:Get-LineageRegistryValueSnapshot}

$steps = @(
    New-LineageFilePublishStep `
        -Name 'Install XLL' `
        -TargetPath $targetPath `
        -StagingPath $targetStaging `
        -BackupPath $targetBackup `
        -TargetExisted $targetExisted `
        -ExpectedTargetHash $installedXllHash `
        -ExpectedPublishedHash $actualHash `
        -EnforceTargetDirectorySnapshot `
        -ExpectedTargetDirectoryNames $preInstallDirectoryNames `
        -PrepareStaging ({
            Copy-Item -LiteralPath $sourcePath -Destination $targetStaging
            Unblock-File -LiteralPath $targetStaging -ErrorAction SilentlyContinue
        }.GetNewClosure())
    New-LineageTrustedLocationInstallStep `
        -Path $trustedLocationPath `
        -ExpectedPath $trustedInstallPath `
        -PathExisted $trustedPathExisted `
        -PathSnapshot $trustedPathSnapshot `
        -AllowSubfoldersSnapshot $trustedSubfoldersSnapshot `
        -DescriptionSnapshot $trustedDescriptionSnapshot `
        -ValueNamesSnapshot $trustedValueNames
    New-LineageRegistryValueInstallStep `
        -Name 'Excel registration' `
        -Path $optionsPath `
        -ValueName $registrationValueName `
        -Value $registrationCommand `
        -Kind ([Microsoft.Win32.RegistryValueKind]::String) `
        -PathExisted $optionsPathExisted `
        -Snapshot $registrationSnapshot
    New-LineageFilePublishStep `
        -Name 'Install receipt' `
        -TargetPath $receiptPath `
        -StagingPath $receiptStaging `
        -BackupPath $receiptBackup `
        -TargetExisted $receiptExisted `
        -ExpectedTargetHash $existingReceiptHash `
        -EnforceTargetDirectorySnapshot `
        -ExpectedTargetDirectoryNames $postXllDirectoryNames `
        -PrepareStaging ({
            $receipt | ConvertTo-Json |
                Set-Content -LiteralPath $receiptStaging -Encoding UTF8
        }.GetNewClosure()) `
        -BeforePublish ({
            $commitRegistrationSnapshot = & $getRegistryValueSnapshot `
                -Path $optionsPath `
                -Name $registrationValueName
            $commitTrustedPathSnapshot = & $getRegistryValueSnapshot `
                -Path $trustedLocationPath `
                -Name 'Path'
            $commitTrustedSubfoldersSnapshot = & $getRegistryValueSnapshot `
                -Path $trustedLocationPath `
                -Name 'AllowSubfolders'
            $commitTrustedDescriptionSnapshot = & $getRegistryValueSnapshot `
                -Path $trustedLocationPath `
                -Name 'Description'
            $commitTrustedValueNames = if (Test-Path -LiteralPath $trustedLocationPath) {
                @((Get-Item -LiteralPath $trustedLocationPath).GetValueNames())
            }
            else { @() }
            & $assertInstalledStateCommitReady `
                -TargetPath $targetPath `
                -ExpectedXllHash $actualHash `
                -RegistrationSnapshot $commitRegistrationSnapshot `
                -ExpectedRegistrationCommand $registrationCommand `
                -TrustedPathSnapshot $commitTrustedPathSnapshot `
                -TrustedSubfoldersSnapshot $commitTrustedSubfoldersSnapshot `
                -TrustedDescriptionSnapshot $commitTrustedDescriptionSnapshot `
                -TrustedValueNames $commitTrustedValueNames `
                -ExpectedTrustedPath $trustedInstallPath
        }.GetNewClosure())
)

$rollbackIncomplete = $false
try {
    Invoke-LineageTransaction -Steps $steps
}
catch {
    if ($_.Exception.Data['LineageRollbackIncomplete'] -eq $true) {
        $rollbackIncomplete = $true
        $message = $_.Exception.Message +
            " Recovery backups were preserved at $backupDirectory."
        throw [InvalidOperationException]::new($message, $_.Exception)
    }
    throw
}
finally {
    if (-not $rollbackIncomplete) {
        Remove-Item -LiteralPath $backupDirectory -Recurse -Force -ErrorAction SilentlyContinue
    }
    if (-not $rollbackIncomplete -and
        -not $installDirectoryExisted -and
        (Test-Path -LiteralPath $installDirectory -PathType Container)) {
        $remaining = @(Get-ChildItem -LiteralPath $installDirectory -Force)
        if ($remaining.Count -eq 0) {
            Remove-Item -LiteralPath $installDirectory -Force
        }
    }
}

Write-Output 'Lineage was installed, integrity-checked, and registered to load automatically with Excel.'

if (-not $SkipLaunch) {
    Start-Process -FilePath 'excel.exe'
}
