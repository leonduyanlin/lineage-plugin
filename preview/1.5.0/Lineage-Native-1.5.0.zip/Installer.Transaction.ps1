Set-StrictMode -Version 2.0

$lineagePackageContractPath = Join-Path $PSScriptRoot 'Lineage.PackageContract.psd1'
if (-not (Test-Path -LiteralPath $lineagePackageContractPath -PathType Leaf)) {
    throw 'The Lineage package contract is missing.'
}
$script:LineagePackageContract = Import-PowerShellDataFile `
    -LiteralPath $lineagePackageContractPath

function Resolve-LineagePackageDistributionChannel {
    [CmdletBinding()]
    param([AllowNull()][string]$Value)

    $channel = if ($null -eq $Value) { '' } else { $Value.Trim() }
    if ($channel -cnotin @('SignedProduction', 'UnsignedPreview')) {
        throw "The Lineage package distribution channel is invalid: '$channel'."
    }
    $channel
}

function Get-LineageInstalledDistributionChannel {
    [CmdletBinding()]
    param([AllowNull()][object]$Receipt)

    if ($null -eq $Receipt -or
        $null -eq $Receipt.PSObject.Properties['distributionChannel'] -or
        [string]::IsNullOrWhiteSpace([string]$Receipt.distributionChannel)) {
        # Receipts created before channel binding came only from the signed/local
        # production package path. Treating them as production fails closed.
        return 'SignedProduction'
    }
    Resolve-LineagePackageDistributionChannel -Value ([string]$Receipt.distributionChannel)
}

function Assert-LineageDistributionChannelTransition {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$IncomingChannel,
        [Parameter(Mandatory = $true)][bool]$ManagedStateExists,
        [AllowNull()][object]$ExistingReceipt
    )

    $incoming = Resolve-LineagePackageDistributionChannel -Value $IncomingChannel
    if (-not $ManagedStateExists) { return }
    $installed = Get-LineageInstalledDistributionChannel -Receipt $ExistingReceipt
    if ($incoming -eq 'UnsignedPreview' -and $installed -eq 'SignedProduction') {
        throw 'Unsigned preview cannot replace an existing signed production installation. Uninstall signed production explicitly before testing a preview.'
    }
}

function Resolve-LineageDistributionBuildOptions {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$DistributionChannel,
        [Parameter(Mandatory = $true)][string]$OutputRoot,
        [AllowNull()][string]$SigningCertificateThumbprint,
        [AllowNull()][string]$TimestampServer
    )

    $channel = Resolve-LineagePackageDistributionChannel -Value $DistributionChannel
    $resolvedOutputRoot = [IO.Path]::GetFullPath($OutputRoot)
    if ($channel -eq 'SignedProduction') {
        if ([string]::IsNullOrWhiteSpace($SigningCertificateThumbprint) -or
            [string]::IsNullOrWhiteSpace($TimestampServer)) {
            throw 'Signed production requires a code-signing certificate thumbprint and timestamp server.'
        }
        return [pscustomobject]@{
            Channel = $channel
            RequiresAuthenticode = $true
            OutputRoot = $resolvedOutputRoot
        }
    }
    if (-not [string]::IsNullOrWhiteSpace($SigningCertificateThumbprint) -or
        -not [string]::IsNullOrWhiteSpace($TimestampServer)) {
        throw 'Unsigned preview must not accept production signing inputs.'
    }
    [pscustomobject]@{
        Channel = $channel
        RequiresAuthenticode = $false
        OutputRoot = [IO.Path]::GetFullPath((Join-Path $resolvedOutputRoot 'unsigned-preview'))
    }
}

function Get-LineageFileByteSnapshot {
    [CmdletBinding()]
    param([Parameter(Mandatory = $true)][string]$Path)
    $bytes = [IO.File]::ReadAllBytes([IO.Path]::GetFullPath($Path))
    $algorithm = [Security.Cryptography.SHA256]::Create()
    try { $hashBytes = $algorithm.ComputeHash($bytes) }
    finally { $algorithm.Dispose() }
    [pscustomobject]@{
        Bytes = $bytes
        Hash = ([BitConverter]::ToString($hashBytes)).Replace('-', '')
    }
}

function ConvertFrom-LineageUtf8Bytes {
    [CmdletBinding()]
    param([Parameter(Mandatory = $true)][byte[]]$Bytes)
    $stream = [IO.MemoryStream]::new($Bytes, $false)
    $reader = [IO.StreamReader]::new($stream, [Text.Encoding]::UTF8, $true)
    try { $reader.ReadToEnd() }
    finally { $reader.Dispose(); $stream.Dispose() }
}

function Get-LineageVerifiedUtf8TextSnapshot {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$ExpectedHash
    )
    $snapshot = Get-LineageFileByteSnapshot -Path $Path
    if (-not [string]::Equals($snapshot.Hash, $ExpectedHash,
        [StringComparison]::OrdinalIgnoreCase)) {
        throw "$(Split-Path $Path -Leaf) failed package integrity verification."
    }
    [pscustomobject]@{
        Hash = $snapshot.Hash
        Text = ConvertFrom-LineageUtf8Bytes -Bytes $snapshot.Bytes
    }
}

function Get-LineageJsonFileSnapshot {
    [CmdletBinding()]
    param([Parameter(Mandatory = $true)][string]$Path)
    $snapshot = Get-LineageFileByteSnapshot -Path $Path
    $text = ConvertFrom-LineageUtf8Bytes -Bytes $snapshot.Bytes
    [pscustomobject]@{
        Hash = $snapshot.Hash
        Value = ($text | ConvertFrom-Json)
    }
}

function Get-LineageManifestEntries {
    [CmdletBinding()]
    param([AllowEmptyCollection()][string[]]$Lines)
    $entries = [Collections.Generic.Dictionary[string,string]]::new(
        [StringComparer]::OrdinalIgnoreCase)
    foreach ($line in @($Lines)) {
        if ([string]::IsNullOrWhiteSpace($line)) { continue }
        $match = [regex]::Match($line, '^([0-9A-Fa-f]{64})\s+\*(.+)$')
        if (-not $match.Success) {
            throw "The package manifest contains an invalid entry: $line"
        }
        $name = $match.Groups[2].Value
        if ($entries.ContainsKey($name)) {
            throw "The package manifest contains a duplicate entry for $name."
        }
        $entries.Add($name, $match.Groups[1].Value.ToUpperInvariant())
    }
    $entries
}

function Assert-LineagePackagePayloadIntegrity {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$PackageDirectory,

        [Parameter(Mandatory = $true)]
        [Collections.Generic.Dictionary[string,string]]$ManifestEntries
    )

    $resolvedPackageDirectory = [IO.Path]::GetFullPath($PackageDirectory)
    if (-not (Test-Path -LiteralPath $resolvedPackageDirectory -PathType Container)) {
        throw "The package directory is missing: $resolvedPackageDirectory"
    }

    $expectedNames = @($script:LineagePackageContract.PackageFiles | Sort-Object)
    $actualNames = @(
        Get-ChildItem -LiteralPath $resolvedPackageDirectory |
            ForEach-Object { if ($_.PSIsContainer) { $_.Name + '\' } else { $_.Name } } |
            Sort-Object
    )
    $packageDifference = Compare-Object -ReferenceObject $expectedNames -DifferenceObject $actualNames
    if ($packageDifference) {
        throw "The package contents differ from the installer allowlist: $($packageDifference | Out-String)"
    }

    $hashedNames = @($expectedNames | Where-Object {
        $_ -notin @('manifest.sha256', 'Lineage.PackageCatalog.psd1')
    } | Sort-Object)
    $manifestNames = @($ManifestEntries.Keys | Sort-Object)
    $manifestDifference = Compare-Object -ReferenceObject $hashedNames -DifferenceObject $manifestNames
    if ($manifestDifference) {
        throw "The package manifest differs from the installer allowlist: $($manifestDifference | Out-String)"
    }

    foreach ($fileName in $hashedNames) {
        $filePath = Join-Path $resolvedPackageDirectory $fileName
        $actualHash = (Get-LineageFileByteSnapshot -Path $filePath).Hash
        if (-not [string]::Equals(
            $actualHash,
            $ManifestEntries[$fileName],
            [StringComparison]::OrdinalIgnoreCase)) {
            throw "$fileName failed package integrity verification."
        }
    }
}

function Assert-LineagePackageVersionSupported {
    [CmdletBinding()]
    param([AllowNull()][string]$PackageVersion)
    if ($PackageVersion -notmatch '^\d+\.\d+\.\d+$') {
        throw 'The package version must be a strict semantic version (major.minor.patch).'
    }
    if ([Version]$PackageVersion -lt [Version]'1.3.0') {
        throw 'The package version is older than the supported transactional installer format.'
    }
}

function Get-LineageRegistrationCommand {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$TargetPath
    )

    $fullPath = [System.IO.Path]::GetFullPath($TargetPath)
    '/R "{0}"' -f $fullPath
}

function Get-LineageOpenRegistrationPath {
    [CmdletBinding()]
    param(
        [AllowNull()]
        [string]$Value
    )

    if ([string]::IsNullOrWhiteSpace($Value)) {
        return $null
    }
    $match = [regex]::Match(
        $Value,
        '^\s*/R\s+(?:"([^"]+)"|(\S+))\s*$',
        [Text.RegularExpressions.RegexOptions]::IgnoreCase)
    if (-not $match.Success) {
        return $null
    }
    $path = if ($match.Groups[1].Success) {
        $match.Groups[1].Value
    }
    else {
        $match.Groups[2].Value
    }
    try {
        [System.IO.Path]::GetFullPath($path)
    }
    catch {
        $null
    }
}

function Test-LineageOpenRegistration {
    [CmdletBinding()]
    param(
        [AllowNull()]
        [string]$Value,
        [Parameter(Mandatory = $true)]
        [string]$TargetPath
    )

    $registeredPath = Get-LineageOpenRegistrationPath -Value $Value
    if ($null -eq $registeredPath) {
        return $false
    }
    [string]::Equals(
        $registeredPath,
        [System.IO.Path]::GetFullPath($TargetPath),
        [StringComparison]::OrdinalIgnoreCase)
}

function Test-LineageReceiptRegistrationOwnership {
    [CmdletBinding()]
    param(
        [AllowNull()]
        [object]$Receipt,
        [Parameter(Mandatory = $true)]
        [string]$ValueName,
        [AllowNull()]
        [string]$Value,
        [Parameter(Mandatory = $true)]
        [Microsoft.Win32.RegistryValueKind]$ValueKind,
        [Parameter(Mandatory = $true)]
        [string]$TargetPath
    )

    if (-not (Test-LineageReceiptIdentity -Receipt $Receipt -TargetPath $TargetPath)) {
        return $false
    }
    $slotProperty = $Receipt.PSObject.Properties['registrationValue']
    $commandProperty = $Receipt.PSObject.Properties['registrationCommand']
    $receiptCommand = [string]$commandProperty.Value
        [string]::Equals(
            [string]$slotProperty.Value,
            $ValueName,
            [StringComparison]::OrdinalIgnoreCase) -and
        $ValueKind -eq [Microsoft.Win32.RegistryValueKind]::String -and
        [string]::Equals($receiptCommand, $Value, [StringComparison]::Ordinal) -and
        (Test-LineageOpenRegistration -Value $Value -TargetPath $TargetPath)
}

function Test-LineageReceiptIdentity {
    [CmdletBinding()]
    param(
        [AllowNull()]
        [object]$Receipt,
        [Parameter(Mandatory = $true)]
        [string]$TargetPath
    )

    if ($null -eq $Receipt) {
        return $false
    }
    $slotProperty = $Receipt.PSObject.Properties['registrationValue']
    $commandProperty = $Receipt.PSObject.Properties['registrationCommand']
    $xllProperty = $Receipt.PSObject.Properties['xll']
    if ($null -eq $slotProperty -or
        $null -eq $commandProperty -or
        $null -eq $xllProperty -or
        [string]$slotProperty.Value -notmatch '^OPEN\d*$' -or
        [string]::IsNullOrWhiteSpace([string]$commandProperty.Value)) {
        return $false
    }
    try {
        if (-not [string]::Equals(
            [System.IO.Path]::GetFullPath([string]$xllProperty.Value),
            [System.IO.Path]::GetFullPath($TargetPath),
            [StringComparison]::OrdinalIgnoreCase)) {
            return $false
        }
    }
    catch {
        return $false
    }
    Test-LineageOpenRegistration `
        -Value ([string]$commandProperty.Value) `
        -TargetPath $TargetPath
}

function Test-LineageLegacy121InstallationOwnership {
    [CmdletBinding()]
    param(
        [AllowNull()]
        [object]$Receipt,
        [Parameter(Mandatory = $true)]
        [string]$TargetPath,
        [Parameter(Mandatory = $true)]
        [ValidateSet('x64', 'x86')]
        [string]$Platform,
        [AllowNull()]
        [string]$InstalledXllHash,
        [Parameter(Mandatory = $true)]
        [string]$RegistrationValueName,
        [Parameter(Mandatory = $true)]
        [object]$RegistrationSnapshot,
        [Parameter(Mandatory = $true)]
        [object]$TrustedPathSnapshot,
        [Parameter(Mandatory = $true)]
        [object]$TrustedSubfoldersSnapshot,
        [Parameter(Mandatory = $true)]
        [object]$TrustedDescriptionSnapshot,
        [AllowEmptyCollection()]
        [string[]]$TrustedValueNames,
        [Parameter(Mandatory = $true)]
        [string]$ExpectedTrustedPath,
        [AllowEmptyCollection()]
        [object[]]$InstallDirectoryItems
    )

    if ($null -eq $Receipt) {
        return $false
    }

    # Version 1.2.1 was the final pre-transactional package. Recognize only its
    # exact five-property receipt shape so this exception cannot become a
    # general ownership claim for later, partially edited, or foreign receipts.
    $expectedReceiptProperties = @(
        'excelArchitecture',
        'installedAt',
        'registrationValue',
        'version',
        'xll'
    )
    $actualReceiptProperties = @(
        $Receipt.PSObject.Properties.Name | Sort-Object
    )
    if ($actualReceiptProperties.Count -ne $expectedReceiptProperties.Count -or
        [string]::Join('|', $actualReceiptProperties) -cne
            [string]::Join('|', $expectedReceiptProperties)) {
        return $false
    }

    if ([string]$Receipt.version -cne '1.2.1' -or
        [string]$Receipt.excelArchitecture -notin @('x64', 'x86') -or
        [string]$Receipt.registrationValue -notmatch '^OPEN\d*$' -or
        -not [string]::Equals(
            [string]$Receipt.registrationValue,
            $RegistrationValueName,
            [StringComparison]::OrdinalIgnoreCase)) {
        return $false
    }
    $installedAt = [DateTimeOffset]::MinValue
    if (-not [DateTimeOffset]::TryParse(
        [string]$Receipt.installedAt,
        [Globalization.CultureInfo]::InvariantCulture,
        [Globalization.DateTimeStyles]::RoundtripKind,
        [ref]$installedAt)) {
        return $false
    }
    try {
        $fullTargetPath = [System.IO.Path]::GetFullPath($TargetPath)
        $receiptTargetPath = [System.IO.Path]::GetFullPath([string]$Receipt.xll)
        $canonicalTrustedPath = (Split-Path $fullTargetPath -Parent) + '\'
    }
    catch {
        return $false
    }
    if (-not [string]::Equals(
            $receiptTargetPath,
            $fullTargetPath,
            [StringComparison]::OrdinalIgnoreCase) -or
        -not [string]::Equals(
            $ExpectedTrustedPath,
            $canonicalTrustedPath,
            [StringComparison]::OrdinalIgnoreCase)) {
        return $false
    }

    # These hashes identify only the exact 2026-08-03 source/deployed build.
    # Other binaries carrying the same 1.2.1 version are intentionally foreign.
    $knownHashes = @{
        x64 = '03F0B8125E4D4D9FAC6B3D221778FBFE21A872A6E713C6011E6951CE1565FA6D'
        x86 = '52A6E8BFB940880B74423FB7BD18D62EC8FDCD298D91C6B0D69AFD5B1465EE82'
    }
    if (-not [string]::Equals(
            $InstalledXllHash,
            $knownHashes[[string]$Receipt.excelArchitecture],
            [StringComparison]::OrdinalIgnoreCase)) {
        return $false
    }

    $expectedCommand = Get-LineageRegistrationCommand -TargetPath $fullTargetPath
    if (-not $RegistrationSnapshot.Exists -or
        $RegistrationSnapshot.Kind -ne [Microsoft.Win32.RegistryValueKind]::String -or
        -not [string]::Equals(
            [string]$RegistrationSnapshot.Value,
            $expectedCommand,
            [StringComparison]::Ordinal)) {
        return $false
    }

    try {
        $trustedLocationOwned = Test-LineageTrustedLocationOwned `
            -PathSnapshot $TrustedPathSnapshot `
            -AllowSubfoldersSnapshot $TrustedSubfoldersSnapshot `
            -DescriptionSnapshot $TrustedDescriptionSnapshot `
            -ExpectedPath $canonicalTrustedPath
    }
    catch {
        return $false
    }
    if (-not $trustedLocationOwned) {
        return $false
    }
    $expectedTrustedValueNames = @('AllowSubfolders', 'Description', 'Path')
    $actualTrustedValueNames = @($TrustedValueNames | Sort-Object)
    if ($actualTrustedValueNames.Count -ne $expectedTrustedValueNames.Count -or
        [string]::Join('|', $actualTrustedValueNames) -cne
            [string]::Join('|', $expectedTrustedValueNames)) {
        return $false
    }

    $allowedNames = @('install.json', 'Lineage.log', 'Lineage.xll')
    $requiredNames = @('install.json', 'Lineage.xll')
    $actualNames = [Collections.Generic.List[string]]::new()
    foreach ($item in @($InstallDirectoryItems)) {
        $nameProperty = $item.PSObject.Properties['Name']
        $containerProperty = $item.PSObject.Properties['PSIsContainer']
        $linkProperty = $item.PSObject.Properties['LinkType']
        $attributesProperty = $item.PSObject.Properties['Attributes']
        if ($null -eq $nameProperty -or
            $null -eq $containerProperty -or
            [bool]$containerProperty.Value -or
            ($null -ne $linkProperty -and
                -not [string]::IsNullOrWhiteSpace([string]$linkProperty.Value)) -or
            ($null -ne $attributesProperty -and
                (([IO.FileAttributes]$attributesProperty.Value -band
                    [IO.FileAttributes]::ReparsePoint) -ne 0))) {
            return $false
        }
        $itemName = [string]$nameProperty.Value
        if ($allowedNames -notcontains $itemName -or
            $actualNames.Contains($itemName)) {
            return $false
        }
        $actualNames.Add($itemName)
    }
    foreach ($requiredName in $requiredNames) {
        if (-not $actualNames.Contains($requiredName)) {
            return $false
        }
    }
    $true
}

function Test-LineageCurrentInstallationOwnership {
    [CmdletBinding()]
    param(
        [AllowNull()][object]$Receipt,
        [Parameter(Mandatory = $true)][string]$TargetPath,
        [Parameter(Mandatory = $true)][string]$PackageVersion,
        [AllowNull()][string]$InstalledXllHash,
        [Parameter(Mandatory = $true)][string]$RegistrationValueName,
        [Parameter(Mandatory = $true)][object]$RegistrationSnapshot,
        [Parameter(Mandatory = $true)][object]$TrustedPathSnapshot,
        [Parameter(Mandatory = $true)][object]$TrustedSubfoldersSnapshot,
        [Parameter(Mandatory = $true)][object]$TrustedDescriptionSnapshot,
        [AllowEmptyCollection()][string[]]$TrustedValueNames,
        [Parameter(Mandatory = $true)][string]$ExpectedTrustedPath,
        [AllowEmptyCollection()][object[]]$InstallDirectoryItems
    )

    if ($null -eq $Receipt) { return $false }
    $expectedProperties = @(
        'excelArchitecture', 'installedAt', 'registrationCommand',
        'registrationValue', 'sha256', 'version', 'xll'
    )
    $actualProperties = @($Receipt.PSObject.Properties.Name | Sort-Object)
    if ($actualProperties.Count -ne $expectedProperties.Count -or
        [string]::Join('|', $actualProperties) -cne
            [string]::Join('|', $expectedProperties)) {
        return $false
    }
    if ([string]$Receipt.version -notmatch '^\d+\.\d+\.\d+$' -or
        [string]$PackageVersion -notmatch '^\d+\.\d+\.\d+$') {
        return $false
    }
    try {
        $receiptVersion = [Version]([string]$Receipt.version)
        $currentPackageVersion = [Version]$PackageVersion
    }
    catch { return $false }
    if ($receiptVersion -lt [Version]'1.3.0' -or
        $receiptVersion -gt $currentPackageVersion -or
        [string]$Receipt.excelArchitecture -notin @('x64', 'x86') -or
        [string]$Receipt.registrationValue -notmatch '^OPEN\d*$' -or
        -not [string]::Equals(
            [string]$Receipt.registrationValue,
            $RegistrationValueName,
            [StringComparison]::OrdinalIgnoreCase)) {
        return $false
    }
    $installedAt = [DateTimeOffset]::MinValue
    if (-not [DateTimeOffset]::TryParse(
        [string]$Receipt.installedAt,
        [Globalization.CultureInfo]::InvariantCulture,
        [Globalization.DateTimeStyles]::RoundtripKind,
        [ref]$installedAt)) {
        return $false
    }
    try {
        $fullTargetPath = [IO.Path]::GetFullPath($TargetPath)
        $receiptTargetPath = [IO.Path]::GetFullPath([string]$Receipt.xll)
        $canonicalTrustedPath = (Split-Path $fullTargetPath -Parent) + '\'
    }
    catch { return $false }
    if (-not [string]::Equals($receiptTargetPath, $fullTargetPath,
            [StringComparison]::OrdinalIgnoreCase) -or
        -not [string]::Equals($ExpectedTrustedPath, $canonicalTrustedPath,
            [StringComparison]::OrdinalIgnoreCase) -or
        [string]$Receipt.sha256 -notmatch '^[0-9A-Fa-f]{64}$' -or
        -not [string]::Equals([string]$Receipt.sha256, $InstalledXllHash,
            [StringComparison]::OrdinalIgnoreCase)) {
        return $false
    }
    $expectedCommand = Get-LineageRegistrationCommand -TargetPath $fullTargetPath
    if (-not [string]::Equals([string]$Receipt.registrationCommand,
            $expectedCommand, [StringComparison]::Ordinal) -or
        -not $RegistrationSnapshot.Exists -or
        $RegistrationSnapshot.Kind -ne [Microsoft.Win32.RegistryValueKind]::String -or
        -not [string]::Equals([string]$RegistrationSnapshot.Value,
            $expectedCommand, [StringComparison]::Ordinal)) {
        return $false
    }
    try {
        if (-not (Test-LineageTrustedLocationOwned `
            -PathSnapshot $TrustedPathSnapshot `
            -AllowSubfoldersSnapshot $TrustedSubfoldersSnapshot `
            -DescriptionSnapshot $TrustedDescriptionSnapshot `
            -ExpectedPath $canonicalTrustedPath)) { return $false }
    }
    catch { return $false }
    $expectedTrustedNames = @('AllowSubfolders', 'Description', 'Path')
    $actualTrustedNames = @($TrustedValueNames | Sort-Object)
    if ($actualTrustedNames.Count -ne $expectedTrustedNames.Count -or
        [string]::Join('|', $actualTrustedNames) -cne
            [string]::Join('|', $expectedTrustedNames)) {
        return $false
    }
    $allowedNames = @('install.json', 'Lineage.log', 'Lineage.xll')
    $requiredNames = @('install.json', 'Lineage.xll')
    $actualNames = [Collections.Generic.List[string]]::new()
    foreach ($item in @($InstallDirectoryItems)) {
        $nameProperty = $item.PSObject.Properties['Name']
        $containerProperty = $item.PSObject.Properties['PSIsContainer']
        $linkProperty = $item.PSObject.Properties['LinkType']
        $attributesProperty = $item.PSObject.Properties['Attributes']
        if ($null -eq $nameProperty -or $null -eq $containerProperty -or
            [bool]$containerProperty.Value -or
            ($null -ne $linkProperty -and
                -not [string]::IsNullOrWhiteSpace([string]$linkProperty.Value)) -or
            ($null -ne $attributesProperty -and
                (([IO.FileAttributes]$attributesProperty.Value -band
                    [IO.FileAttributes]::ReparsePoint) -ne 0))) {
            return $false
        }
        $itemName = [string]$nameProperty.Value
        if ($allowedNames -notcontains $itemName -or $actualNames.Contains($itemName)) {
            return $false
        }
        $actualNames.Add($itemName)
    }
    foreach ($requiredName in $requiredNames) {
        if (-not $actualNames.Contains($requiredName)) { return $false }
    }
    $true
}

function Test-LineageInstallationOwnership {
    [CmdletBinding()]
    param(
        [AllowNull()][object]$Receipt,
        [Parameter(Mandatory = $true)][string]$TargetPath,
        [Parameter(Mandatory = $true)][string]$PackageVersion,
        [Parameter(Mandatory = $true)][ValidateSet('x64', 'x86')][string]$Platform,
        [AllowNull()][string]$InstalledXllHash,
        [Parameter(Mandatory = $true)][string]$RegistrationValueName,
        [Parameter(Mandatory = $true)][object]$RegistrationSnapshot,
        [Parameter(Mandatory = $true)][object]$TrustedPathSnapshot,
        [Parameter(Mandatory = $true)][object]$TrustedSubfoldersSnapshot,
        [Parameter(Mandatory = $true)][object]$TrustedDescriptionSnapshot,
        [AllowEmptyCollection()][string[]]$TrustedValueNames,
        [Parameter(Mandatory = $true)][string]$ExpectedTrustedPath,
        [AllowEmptyCollection()][object[]]$InstallDirectoryItems
    )

    $common = @{
        Receipt = $Receipt
        TargetPath = $TargetPath
        InstalledXllHash = $InstalledXllHash
        RegistrationValueName = $RegistrationValueName
        RegistrationSnapshot = $RegistrationSnapshot
        TrustedPathSnapshot = $TrustedPathSnapshot
        TrustedSubfoldersSnapshot = $TrustedSubfoldersSnapshot
        TrustedDescriptionSnapshot = $TrustedDescriptionSnapshot
        TrustedValueNames = $TrustedValueNames
        ExpectedTrustedPath = $ExpectedTrustedPath
        InstallDirectoryItems = $InstallDirectoryItems
    }
    if (Test-LineageCurrentInstallationOwnership `
        @common `
        -PackageVersion $PackageVersion) {
        return $true
    }
    Test-LineageLegacy121InstallationOwnership @common -Platform $Platform
}

function Assert-LineageExistingManagedStateOwned {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][bool]$ManagedStateExists,
        [Parameter(Mandatory = $true)][bool]$OwnershipVerified,
        [switch]$Legacy121ReceiptPresent
    )

    if (-not $ManagedStateExists -or $OwnershipVerified) { return }
    if ($Legacy121ReceiptPresent) {
        throw 'Refusing to upgrade an unsupported or unrecognized Lineage 1.2.1 fingerprint.'
    }
    throw 'Refusing to overwrite existing unowned Lineage managed state.'
}

function Assert-LineageUninstallStateOwned {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][bool]$ManagedStateExists,
        [Parameter(Mandatory = $true)][bool]$OwnershipVerified
    )

    if (-not $ManagedStateExists -or $OwnershipVerified) {
        return
    }
    throw 'Refusing to remove existing unowned Lineage managed state.'
}

function Test-LineageManagedStateExists {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][bool]$TargetExists,
        [Parameter(Mandatory = $true)][bool]$ReceiptExists,
        [Parameter(Mandatory = $true)][bool]$ExactRegistrationFound,
        [Parameter(Mandatory = $true)][bool]$TrustedPathExists,
        [AllowNull()][AllowEmptyCollection()][object[]]$InstallDirectoryItems
    )
    return $TargetExists -or
        $ReceiptExists -or
        $ExactRegistrationFound -or
        $TrustedPathExists -or
        (@($InstallDirectoryItems | Where-Object { $null -ne $_ }).Count -gt 0)
}

function Assert-LineageNoReparsePath {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$Label
    )
    $current = [IO.Path]::GetFullPath($Path)
    $isDirect = $true
    while (-not [string]::IsNullOrWhiteSpace($current)) {
        if (Test-Path -LiteralPath $current) {
            $item = Get-Item -LiteralPath $current -Force
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 -or
                -not [string]::IsNullOrWhiteSpace([string]$item.LinkType)) {
                $location = if ($isDirect) { 'path' } else { 'ancestor' }
                throw "$Label $location must not be a reparse point: $current"
            }
        }
        $parent = [IO.Path]::GetDirectoryName($current)
        if ([string]::IsNullOrWhiteSpace($parent) -or
            [string]::Equals($parent, $current, [StringComparison]::OrdinalIgnoreCase)) {
            break
        }
        $current = $parent
        $isDirect = $false
    }
}

function Assert-LineageLeafOrMissing {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,
        [Parameter(Mandatory = $true)]
        [string]$Label
    )

    Assert-LineageNoReparsePath -Path $Path -Label $Label
    if (Test-Path -LiteralPath $Path) {
        if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
            throw "$Label must be a file when it already exists: $Path"
        }
    }
}

function Assert-LineageDirectorySafeOrMissing {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$Label
    )
    Assert-LineageNoReparsePath -Path $Path -Label $Label
    if (-not (Test-Path -LiteralPath $Path)) { return }
    if (-not (Test-Path -LiteralPath $Path -PathType Container)) {
        throw "$Label must be a directory when it already exists: $Path"
    }
}

function New-LineageRegistryValueSnapshotFromKey {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$Key,
        [Parameter(Mandatory = $true)]
        [string]$Name
    )

    if (@($Key.GetValueNames()) -notcontains $Name) {
        return [pscustomobject]@{
            Exists = $false
            Value = $null
            Kind = $null
        }
    }
    [pscustomobject]@{
        Exists = $true
        Value = $Key.GetValue(
            $Name,
            $null,
            [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
        Kind = $Key.GetValueKind($Name)
    }
}

function New-LineageOwnedRegistryValueSnapshot {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Name,
        [AllowNull()]
        [object]$Value,
        [Parameter(Mandatory = $true)]
        [Microsoft.Win32.RegistryValueKind]$Kind
    )

    [pscustomobject]@{
        Name = $Name
        Exists = $true
        Value = $Value
        Kind = $Kind
    }
}

function Get-LineageRegistryValueSnapshot {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,
        [Parameter(Mandatory = $true)]
        [string]$Name,
        [hashtable]$Adapter
    )

    if ($null -ne $Adapter) {
        return & $Adapter['GetValueSnapshot'] $Path $Name
    }
    if (-not (Test-Path -LiteralPath $Path)) {
        return [pscustomobject]@{
            Exists = $false
            Value = $null
            Kind = $null
        }
    }
    $key = Get-Item -LiteralPath $Path
    if (@($key.GetValueNames()) -notcontains $Name) {
        return [pscustomobject]@{
            Exists = $false
            Value = $null
            Kind = $null
        }
    }
    [pscustomobject]@{
        Exists = $true
        Value = $key.GetValue(
            $Name,
            $null,
            [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
        Kind = $key.GetValueKind($Name)
    }
}

function Get-LineageRegistryValueNames {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [hashtable]$Adapter
    )
    if ($null -ne $Adapter) {
        return @(& $Adapter['GetValueNames'] $Path)
    }
    if (-not (Test-Path -LiteralPath $Path)) { return @() }
    @((Get-Item -LiteralPath $Path).GetValueNames())
}

function Test-LineageRegistryPath {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,
        [hashtable]$Adapter
    )

    if ($null -ne $Adapter) {
        return [bool](& $Adapter['TestPath'] $Path)
    }
    Test-Path -LiteralPath $Path
}

function New-LineageRegistryPath {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,
        [hashtable]$Adapter
    )

    if ($null -ne $Adapter) {
        & $Adapter['CreatePath'] $Path
        return
    }
    [void](New-Item -Path $Path -Force)
}

function Test-LineageRegistryValue {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,
        [Parameter(Mandatory = $true)]
        [string]$Name,
        [hashtable]$Adapter
    )

    if ($null -ne $Adapter) {
        return [bool](& $Adapter['HasValue'] $Path $Name)
    }
    if (-not (Test-Path -LiteralPath $Path)) {
        return $false
    }
    (Get-Item -LiteralPath $Path).GetValueNames() -contains $Name
}

function Set-LineageRegistryValue {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,
        [Parameter(Mandatory = $true)]
        [string]$Name,
        [AllowNull()]
        [object]$Value,
        [Parameter(Mandatory = $true)]
        [Microsoft.Win32.RegistryValueKind]$Kind,
        [hashtable]$Adapter
    )

    if ($null -ne $Adapter) {
        & $Adapter['SetValue'] $Path $Name $Value $Kind
        return
    }
    New-ItemProperty `
        -Path $Path `
        -Name $Name `
        -Value $Value `
        -PropertyType $Kind `
        -Force | Out-Null
}

function Remove-LineageRegistryValue {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,
        [Parameter(Mandatory = $true)]
        [string]$Name,
        [hashtable]$Adapter
    )

    if ($null -ne $Adapter) {
        & $Adapter['RemoveValue'] $Path $Name
        return
    }
    Remove-ItemProperty -LiteralPath $Path -Name $Name
}

function Test-LineageRegistryPathEmpty {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,
        [hashtable]$Adapter
    )

    if ($null -ne $Adapter) {
        return [bool](& $Adapter['IsPathEmpty'] $Path)
    }
    $key = Get-Item -LiteralPath $Path
    $key.GetValueNames().Count -eq 0 -and $key.SubKeyCount -eq 0
}

function Remove-LineageRegistryPath {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,
        [hashtable]$Adapter
    )

    if ($null -ne $Adapter) {
        & $Adapter['RemovePath'] $Path
        return
    }
    Remove-Item -LiteralPath $Path -Force
}

function Test-LineageRegistrySnapshotsEqual {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$First,
        [Parameter(Mandatory = $true)]
        [object]$Second
    )

    if ([bool]$First.Exists -ne [bool]$Second.Exists) {
        return $false
    }
    if (-not $First.Exists) {
        return $true
    }
    if ($First.Kind -ne $Second.Kind) {
        return $false
    }
    if ($First.Value -is [byte[]] -or $Second.Value -is [byte[]]) {
        if ($First.Value -isnot [byte[]] -or $Second.Value -isnot [byte[]] -or
            $First.Value.Length -ne $Second.Value.Length) {
            return $false
        }
        for ($index = 0; $index -lt $First.Value.Length; $index++) {
            if ($First.Value[$index] -ne $Second.Value[$index]) {
                return $false
            }
        }
        return $true
    }
    if ($First.Value -is [string] -or $Second.Value -is [string]) {
        return [string]::Equals(
            [string]$First.Value,
            [string]$Second.Value,
            [StringComparison]::Ordinal)
    }
    [object]::Equals($First.Value, $Second.Value)
}

function Restore-LineageRegistryValue {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,
        [Parameter(Mandatory = $true)]
        [string]$Name,
        [Parameter(Mandatory = $true)]
        [object]$Snapshot,
        [hashtable]$Adapter
    )

    if ($null -ne $Adapter) {
        $pathExists = & $Adapter['TestPath'] $Path
        if ($Snapshot.Exists) {
            if (-not $pathExists) {
                & $Adapter['CreatePath'] $Path
            }
            & $Adapter['SetValue'] `
                $Path `
                $Name `
                $Snapshot.Value `
                $Snapshot.Kind
        }
        elseif ($pathExists -and (& $Adapter['HasValue'] $Path $Name)) {
            & $Adapter['RemoveValue'] $Path $Name
        }
        return
    }

    if ($Snapshot.Exists) {
        if (-not (Test-Path -LiteralPath $Path)) {
            [void](New-Item -Path $Path -Force)
        }
        New-ItemProperty `
            -Path $Path `
            -Name $Name `
            -Value $Snapshot.Value `
            -PropertyType $Snapshot.Kind `
            -Force | Out-Null
    }
    elseif (Test-Path -LiteralPath $Path) {
        $key = Get-Item -LiteralPath $Path
        if ($key.GetValueNames() -contains $Name) {
            Remove-ItemProperty -LiteralPath $Path -Name $Name
        }
    }
}

function New-LineageRegistryValueInstallStep {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Name,
        [Parameter(Mandatory = $true)]
        [string]$Path,
        [Parameter(Mandatory = $true)]
        [string]$ValueName,
        [AllowNull()]
        [object]$Value,
        [Parameter(Mandatory = $true)]
        [Microsoft.Win32.RegistryValueKind]$Kind,
        [Parameter(Mandatory = $true)]
        [bool]$PathExisted,
        [Parameter(Mandatory = $true)]
        [object]$Snapshot,
        [hashtable]$Adapter,
        [scriptblock]$FailureInjector = { param($Boundary) }
    )

    $testRegistryPath = ${function:Test-LineageRegistryPath}
    $newRegistryPath = ${function:New-LineageRegistryPath}
    $getRegistryValueSnapshot = ${function:Get-LineageRegistryValueSnapshot}
    $testRegistrySnapshotsEqual = ${function:Test-LineageRegistrySnapshotsEqual}
    $setRegistryValue = ${function:Set-LineageRegistryValue}
    $restoreRegistryValue = ${function:Restore-LineageRegistryValue}
    $testRegistryPathEmpty = ${function:Test-LineageRegistryPathEmpty}
    $removeRegistryPath = ${function:Remove-LineageRegistryPath}
    $stepState = [pscustomobject]@{ ValueWritten = $false; PathCreated = $false }
    $apply = {
        $currentPathExists = & $testRegistryPath -Path $Path -Adapter $Adapter
        if ([bool]$currentPathExists -ne $PathExisted) {
            throw "$Name changed after installer preflight; refusing to overwrite registry drift."
        }
        $currentSnapshot = & $getRegistryValueSnapshot `
            -Path $Path -Name $ValueName -Adapter $Adapter
        if (-not (& $testRegistrySnapshotsEqual -First $currentSnapshot -Second $Snapshot)) {
            throw "$Name changed after installer preflight; refusing to overwrite registry drift."
        }
        if (-not $currentPathExists) {
            & $newRegistryPath -Path $Path -Adapter $Adapter
            $stepState.PathCreated = $true
        }
        & $setRegistryValue `
            -Path $Path `
            -Name $ValueName `
            -Value $Value `
            -Kind $Kind `
            -Adapter $Adapter
        $stepState.ValueWritten = $true
        & $FailureInjector 'AfterValueWrite'
    }.GetNewClosure()
    $rollback = {
        if ($stepState.ValueWritten) {
            $installedSnapshot = [pscustomobject]@{
                Exists = $true; Value = $Value; Kind = $Kind
            }
            $currentSnapshot = & $getRegistryValueSnapshot `
                -Path $Path -Name $ValueName -Adapter $Adapter
            if (-not (& $testRegistrySnapshotsEqual `
                -First $currentSnapshot -Second $installedSnapshot)) {
                throw "$Name changed after installer write; refusing stale rollback."
            }
            & $restoreRegistryValue `
                -Path $Path -Name $ValueName -Snapshot $Snapshot -Adapter $Adapter
        }
        if ($stepState.PathCreated -and
            (& $testRegistryPath -Path $Path -Adapter $Adapter) -and
            (& $testRegistryPathEmpty -Path $Path -Adapter $Adapter)) {
            & $removeRegistryPath -Path $Path -Adapter $Adapter
        }
    }.GetNewClosure()
    New-LineageTransactionStep -Name $Name -Apply $apply -Rollback $rollback
}

function New-LineageTrustedLocationInstallStep {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,
        [Parameter(Mandatory = $true)]
        [string]$ExpectedPath,
        [Parameter(Mandatory = $true)]
        [bool]$PathExisted,
        [Parameter(Mandatory = $true)]
        [object]$PathSnapshot,
        [Parameter(Mandatory = $true)]
        [object]$AllowSubfoldersSnapshot,
        [Parameter(Mandatory = $true)]
        [object]$DescriptionSnapshot,
        [AllowEmptyCollection()]
        [string[]]$ValueNamesSnapshot,
        [hashtable]$Adapter,
        [scriptblock]$FailureInjector = { param($Boundary) }
    )

    $testRegistryPath = ${function:Test-LineageRegistryPath}
    $newRegistryPath = ${function:New-LineageRegistryPath}
    $getRegistryValueSnapshot = ${function:Get-LineageRegistryValueSnapshot}
    $getRegistryValueNames = ${function:Get-LineageRegistryValueNames}
    $testRegistrySnapshotsEqual = ${function:Test-LineageRegistrySnapshotsEqual}
    $setRegistryValue = ${function:Set-LineageRegistryValue}
    $restoreRegistryValue = ${function:Restore-LineageRegistryValue}
    $testRegistryPathEmpty = ${function:Test-LineageRegistryPathEmpty}
    $removeRegistryPath = ${function:Remove-LineageRegistryPath}
    $stepState = [pscustomobject]@{
        PathCreated = $false
        WrittenNames = [Collections.Generic.List[string]]::new()
    }
    $assertTrustWriteState = {
        param($ValueName, $ValueSnapshot)
        $currentNames = @(& $getRegistryValueNames -Path $Path -Adapter $Adapter | Sort-Object)
        $expectedNames = @(
            @($ValueNamesSnapshot) + @($stepState.WrittenNames) |
                Select-Object -Unique |
                Sort-Object
        )
        if ([string]::Join('|', $currentNames) -cne
            [string]::Join('|', $expectedNames)) {
            throw 'Trusted location changed between installer writes; refusing registry drift.'
        }
        $installedStates = @{
            Path = [pscustomobject]@{ Exists = $true; Value = $ExpectedPath; Kind = [Microsoft.Win32.RegistryValueKind]::String }
            AllowSubfolders = [pscustomobject]@{ Exists = $true; Value = 0; Kind = [Microsoft.Win32.RegistryValueKind]::DWord }
            Description = [pscustomobject]@{ Exists = $true; Value = 'Lineage native Excel add-in'; Kind = [Microsoft.Win32.RegistryValueKind]::String }
        }
        foreach ($writtenName in $stepState.WrittenNames) {
            $currentWritten = & $getRegistryValueSnapshot `
                -Path $Path -Name $writtenName -Adapter $Adapter
            if (-not (& $testRegistrySnapshotsEqual `
                -First $currentWritten -Second $installedStates[$writtenName])) {
                throw 'Trusted location changed between installer writes; refusing registry drift.'
            }
        }
        if (-not [string]::IsNullOrWhiteSpace([string]$ValueName)) {
            $current = & $getRegistryValueSnapshot `
                -Path $Path -Name $ValueName -Adapter $Adapter
            if (-not (& $testRegistrySnapshotsEqual -First $current -Second $ValueSnapshot)) {
                throw 'Trusted location changed between installer writes; refusing registry drift.'
            }
        }
    }.GetNewClosure()
    $apply = {
        $currentPathExists = & $testRegistryPath -Path $Path -Adapter $Adapter
        if ([bool]$currentPathExists -ne $PathExisted) {
            throw 'Trusted location changed after installer preflight; refusing registry drift.'
        }
        $currentNames = @(& $getRegistryValueNames -Path $Path -Adapter $Adapter | Sort-Object)
        $expectedNames = @($ValueNamesSnapshot | Sort-Object)
        if ([string]::Join('|', $currentNames) -cne [string]::Join('|', $expectedNames)) {
            throw 'Trusted location changed after installer preflight; refusing registry drift.'
        }
        foreach ($valueState in @(
            [pscustomobject]@{ Name = 'Path'; Snapshot = $PathSnapshot },
            [pscustomobject]@{ Name = 'AllowSubfolders'; Snapshot = $AllowSubfoldersSnapshot },
            [pscustomobject]@{ Name = 'Description'; Snapshot = $DescriptionSnapshot }
        )) {
            $current = & $getRegistryValueSnapshot `
                -Path $Path -Name $valueState.Name -Adapter $Adapter
            if (-not (& $testRegistrySnapshotsEqual -First $current -Second $valueState.Snapshot)) {
                throw 'Trusted location changed after installer preflight; refusing registry drift.'
            }
        }
        if (-not $currentPathExists) {
            & $newRegistryPath -Path $Path -Adapter $Adapter
            $stepState.PathCreated = $true
        }
        & $assertTrustWriteState 'Path' $PathSnapshot
        & $setRegistryValue `
            -Path $Path `
            -Name 'Path' `
            -Value $ExpectedPath `
            -Kind ([Microsoft.Win32.RegistryValueKind]::String) `
            -Adapter $Adapter
        $stepState.WrittenNames.Add('Path')
        & $FailureInjector 'AfterPathWrite'
        & $assertTrustWriteState 'AllowSubfolders' $AllowSubfoldersSnapshot
        & $setRegistryValue `
            -Path $Path `
            -Name 'AllowSubfolders' `
            -Value 0 `
            -Kind ([Microsoft.Win32.RegistryValueKind]::DWord) `
            -Adapter $Adapter
        $stepState.WrittenNames.Add('AllowSubfolders')
        & $FailureInjector 'AfterAllowSubfoldersWrite'
        & $assertTrustWriteState 'Description' $DescriptionSnapshot
        & $setRegistryValue `
            -Path $Path `
            -Name 'Description' `
            -Value 'Lineage native Excel add-in' `
            -Kind ([Microsoft.Win32.RegistryValueKind]::String) `
            -Adapter $Adapter
        $stepState.WrittenNames.Add('Description')
        & $FailureInjector 'AfterDescriptionWrite'
        & $assertTrustWriteState $null $null
    }.GetNewClosure()
    $rollback = {
        $allStates = @(
            [pscustomobject]@{
                Name = 'Path'; Snapshot = $PathSnapshot
                Installed = [pscustomobject]@{ Exists = $true; Value = $ExpectedPath; Kind = [Microsoft.Win32.RegistryValueKind]::String }
            },
            [pscustomobject]@{
                Name = 'AllowSubfolders'; Snapshot = $AllowSubfoldersSnapshot
                Installed = [pscustomobject]@{ Exists = $true; Value = 0; Kind = [Microsoft.Win32.RegistryValueKind]::DWord }
            },
            [pscustomobject]@{
                Name = 'Description'; Snapshot = $DescriptionSnapshot
                Installed = [pscustomobject]@{ Exists = $true; Value = 'Lineage native Excel add-in'; Kind = [Microsoft.Win32.RegistryValueKind]::String }
            }
        )
        foreach ($valueState in $allStates) {
            if (-not $stepState.WrittenNames.Contains($valueState.Name)) { continue }
            $current = & $getRegistryValueSnapshot `
                -Path $Path -Name $valueState.Name -Adapter $Adapter
            if (-not (& $testRegistrySnapshotsEqual -First $current -Second $valueState.Installed)) {
                throw 'Trusted location changed after installer write; refusing stale rollback.'
            }
        }
        foreach ($valueState in $allStates) {
            if (-not $stepState.WrittenNames.Contains($valueState.Name)) { continue }
            & $restoreRegistryValue `
                -Path $Path `
                -Name $valueState.Name `
                -Snapshot $valueState.Snapshot `
                -Adapter $Adapter
        }
        if ($stepState.PathCreated -and
            (& $testRegistryPath -Path $Path -Adapter $Adapter) -and
            (& $testRegistryPathEmpty -Path $Path -Adapter $Adapter)) {
            & $removeRegistryPath -Path $Path -Adapter $Adapter
        }
    }.GetNewClosure()
    New-LineageTransactionStep -Name 'Trusted location' -Apply $apply -Rollback $rollback
}

function New-LineageOwnedRegistryRemovalStep {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Name,
        [Parameter(Mandatory = $true)]
        [string]$Path,
        [Parameter(Mandatory = $true)]
        [AllowEmptyCollection()]
        [object[]]$ValueSnapshots,
        [Parameter(Mandatory = $true)]
        [bool]$OwnershipVerified,
        [switch]$RemovePathWhenEmpty,
        [hashtable]$Adapter,
        [scriptblock]$FailureInjector = { param($Boundary) }
    )

    $removedSnapshots = [System.Collections.Generic.List[object]]::new()
    $testRegistryPath = ${function:Test-LineageRegistryPath}
    $getRegistryValueSnapshot = ${function:Get-LineageRegistryValueSnapshot}
    $testRegistrySnapshotsEqual = ${function:Test-LineageRegistrySnapshotsEqual}
    $removeRegistryValue = ${function:Remove-LineageRegistryValue}
    $testRegistryPathEmpty = ${function:Test-LineageRegistryPathEmpty}
    $removeRegistryPath = ${function:Remove-LineageRegistryPath}
    $restoreRegistryValue = ${function:Restore-LineageRegistryValue}
    $apply = {
        if (-not $OwnershipVerified) {
            return
        }
        foreach ($snapshot in $ValueSnapshots) {
            if (-not (& $testRegistryPath -Path $Path -Adapter $Adapter)) {
                break
            }
            $current = & $getRegistryValueSnapshot `
                -Path $Path `
                -Name $snapshot.Name `
                -Adapter $Adapter
            if (& $testRegistrySnapshotsEqual -First $current -Second $snapshot) {
                & $removeRegistryValue `
                    -Path $Path `
                    -Name $snapshot.Name `
                    -Adapter $Adapter
                $removedSnapshots.Add($snapshot)
                & $FailureInjector ('AfterValueRemove:{0}' -f $snapshot.Name)
            }
        }
        if ($RemovePathWhenEmpty -and
            (& $testRegistryPath -Path $Path -Adapter $Adapter) -and
            (& $testRegistryPathEmpty -Path $Path -Adapter $Adapter)) {
            & $removeRegistryPath -Path $Path -Adapter $Adapter
            & $FailureInjector 'AfterPathRemove'
        }
    }.GetNewClosure()
    $rollback = {
        foreach ($snapshot in $removedSnapshots) {
            & $restoreRegistryValue `
                -Path $Path `
                -Name $snapshot.Name `
                -Snapshot $snapshot `
                -Adapter $Adapter
        }
    }.GetNewClosure()
    New-LineageTransactionStep -Name $Name -Apply $apply -Rollback $rollback
}

function Test-LineageTrustedLocationOwned {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$PathSnapshot,
        [Parameter(Mandatory = $true)]
        [object]$AllowSubfoldersSnapshot,
        [Parameter(Mandatory = $true)]
        [object]$DescriptionSnapshot,
        [Parameter(Mandatory = $true)]
        [string]$ExpectedPath
    )

    $PathSnapshot.Exists -and
        $AllowSubfoldersSnapshot.Exists -and
        $DescriptionSnapshot.Exists -and
        $PathSnapshot.Kind -eq [Microsoft.Win32.RegistryValueKind]::String -and
        $AllowSubfoldersSnapshot.Kind -eq [Microsoft.Win32.RegistryValueKind]::DWord -and
        $DescriptionSnapshot.Kind -eq [Microsoft.Win32.RegistryValueKind]::String -and
        [string]::Equals(
            [string]$PathSnapshot.Value,
            $ExpectedPath,
            [StringComparison]::OrdinalIgnoreCase) -and
        [Convert]::ToInt32($AllowSubfoldersSnapshot.Value) -eq 0 -and
        [string]::Equals(
            [string]$DescriptionSnapshot.Value,
            'Lineage native Excel add-in',
            [StringComparison]::Ordinal)
}

function Assert-LineageInstalledStateCommitReady {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$TargetPath,
        [Parameter(Mandatory = $true)][string]$ExpectedXllHash,
        [Parameter(Mandatory = $true)][object]$RegistrationSnapshot,
        [Parameter(Mandatory = $true)][string]$ExpectedRegistrationCommand,
        [Parameter(Mandatory = $true)][object]$TrustedPathSnapshot,
        [Parameter(Mandatory = $true)][object]$TrustedSubfoldersSnapshot,
        [Parameter(Mandatory = $true)][object]$TrustedDescriptionSnapshot,
        [AllowEmptyCollection()][string[]]$TrustedValueNames,
        [Parameter(Mandatory = $true)][string]$ExpectedTrustedPath
    )
    Assert-LineageLeafOrMissing -Path $TargetPath -Label 'Installed Lineage XLL'
    if (-not (Test-Path -LiteralPath $TargetPath -PathType Leaf) -or
        -not [string]::Equals(
            (Get-FileHash -LiteralPath $TargetPath -Algorithm SHA256).Hash,
            $ExpectedXllHash,
            [StringComparison]::OrdinalIgnoreCase)) {
        throw 'Installed Lineage XLL changed before receipt commit.'
    }
    if (-not $RegistrationSnapshot.Exists -or
        $RegistrationSnapshot.Kind -ne [Microsoft.Win32.RegistryValueKind]::String -or
        -not [string]::Equals(
            [string]$RegistrationSnapshot.Value,
            $ExpectedRegistrationCommand,
            [StringComparison]::Ordinal)) {
        throw 'Excel registration changed before receipt commit.'
    }
    if (-not (Test-LineageTrustedLocationOwned `
        -PathSnapshot $TrustedPathSnapshot `
        -AllowSubfoldersSnapshot $TrustedSubfoldersSnapshot `
        -DescriptionSnapshot $TrustedDescriptionSnapshot `
        -ExpectedPath $ExpectedTrustedPath)) {
        throw 'Trusted location changed before receipt commit.'
    }
    $expectedNames = @('AllowSubfolders', 'Description', 'Path')
    $actualNames = @($TrustedValueNames | Sort-Object)
    if ($actualNames.Count -ne $expectedNames.Count -or
        [string]::Join('|', $actualNames) -cne [string]::Join('|', $expectedNames)) {
        throw 'Trusted location names changed before receipt commit.'
    }
}

function Assert-LineageTrustedLocationCompatible {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$PathSnapshot,
        [Parameter(Mandatory = $true)]
        [object]$AllowSubfoldersSnapshot,
        [Parameter(Mandatory = $true)]
        [object]$DescriptionSnapshot,
        [Parameter(Mandatory = $true)]
        [string]$ExpectedPath,
        [Parameter(Mandatory = $true)]
        [bool]$PriorInstallationOwned
    )

    $allMissing = -not $PathSnapshot.Exists -and
        -not $AllowSubfoldersSnapshot.Exists -and
        -not $DescriptionSnapshot.Exists
    if ($allMissing -or
        ($PriorInstallationOwned -and
            (Test-LineageTrustedLocationOwned `
                -PathSnapshot $PathSnapshot `
                -AllowSubfoldersSnapshot $AllowSubfoldersSnapshot `
                -DescriptionSnapshot $DescriptionSnapshot `
                -ExpectedPath $ExpectedPath))) {
        return
    }
    throw 'Refusing to overwrite conflicting trusted-location values at LineageNative.'
}

function New-LineageFilePublishStep {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Name,
        [Parameter(Mandatory = $true)]
        [string]$TargetPath,
        [Parameter(Mandatory = $true)]
        [string]$StagingPath,
        [Parameter(Mandatory = $true)]
        [string]$BackupPath,
        [Parameter(Mandatory = $true)]
        [bool]$TargetExisted,
        [AllowNull()]
        [string]$ExpectedTargetHash,
        [AllowNull()]
        [string]$ExpectedPublishedHash,
        [switch]$EnforceTargetDirectorySnapshot,
        [AllowEmptyCollection()]
        [string[]]$ExpectedTargetDirectoryNames,
        [Parameter(Mandatory = $true)]
        [scriptblock]$PrepareStaging,
        [scriptblock]$BeforePublish = { },
        [scriptblock]$AfterPublish = { }
    )

    $assertDirectorySafe = ${function:Assert-LineageDirectorySafeOrMissing}
    $assertLeafOrMissing = ${function:Assert-LineageLeafOrMissing}
    $targetDirectory = Split-Path $TargetPath -Parent
    $stepState = [pscustomobject]@{ TargetPublished = $false; PublishedHash = $null }
    $assertDirectoryNames = {
        param([string[]]$ExpectedNames, [string]$Phase)
        $actualItems = @(Get-ChildItem -LiteralPath $targetDirectory -Force)
        foreach ($item in $actualItems) {
            if ($item.PSIsContainer -or
                ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 -or
                -not [string]::IsNullOrWhiteSpace([string]$item.LinkType)) {
                throw "$Name target directory must contain only non-reparse files $Phase."
            }
        }
        $actualNames = @($actualItems | ForEach-Object { $_.Name } | Sort-Object)
        $sortedExpected = @($ExpectedNames | Sort-Object)
        if ($actualNames.Count -ne $sortedExpected.Count -or
            -not [string]::Equals(
                [string]::Join('|', $actualNames),
                [string]::Join('|', $sortedExpected),
                [StringComparison]::OrdinalIgnoreCase)) {
            throw "$Name target directory contents changed $Phase; refusing file drift."
        }
    }.GetNewClosure()
    $apply = {
        & $assertDirectorySafe `
            -Path $targetDirectory `
            -Label "$Name target directory"
        if (-not (Test-Path -LiteralPath $targetDirectory -PathType Container)) {
            [void](New-Item -ItemType Directory -Path $targetDirectory)
        }
        if ($EnforceTargetDirectorySnapshot) {
            & $assertDirectoryNames $ExpectedTargetDirectoryNames 'after installer preflight'
        }
        $currentTargetExists = Test-Path -LiteralPath $TargetPath
        if ([bool]$currentTargetExists -ne $TargetExisted) {
            throw "$Name changed after installer preflight; refusing to overwrite file drift."
        }
        if ($TargetExisted) {
            & $assertLeafOrMissing -Path $TargetPath -Label $Name
            $currentHash = (Get-FileHash -LiteralPath $TargetPath -Algorithm SHA256).Hash
            if ([string]::IsNullOrWhiteSpace($ExpectedTargetHash) -or
                -not [string]::Equals($currentHash, $ExpectedTargetHash,
                    [StringComparison]::OrdinalIgnoreCase)) {
                throw "$Name changed after installer preflight; refusing to overwrite file drift."
            }
            Copy-Item -LiteralPath $TargetPath -Destination $BackupPath
        }
        & $PrepareStaging
        & $assertLeafOrMissing -Path $StagingPath -Label "$Name staging file"
        $preparedHash = (Get-FileHash -LiteralPath $StagingPath -Algorithm SHA256).Hash
        if (-not [string]::IsNullOrWhiteSpace($ExpectedPublishedHash) -and
            -not [string]::Equals(
                $preparedHash,
                $ExpectedPublishedHash,
                [StringComparison]::OrdinalIgnoreCase)) {
            throw "$Name staged content failed expected hash verification."
        }
        & $BeforePublish
        # PrepareStaging can execute arbitrary copy/unblock work. Bind the
        # target snapshot again immediately before the destructive move.
        & $assertDirectorySafe `
            -Path $targetDirectory `
            -Label "$Name target directory"
        $currentTargetExists = Test-Path -LiteralPath $TargetPath
        if ([bool]$currentTargetExists -ne $TargetExisted) {
            throw "$Name changed during staging preparation; refusing file drift."
        }
        if ($TargetExisted) {
            & $assertLeafOrMissing -Path $TargetPath -Label $Name
            $currentHash = (Get-FileHash -LiteralPath $TargetPath -Algorithm SHA256).Hash
            if ([string]::IsNullOrWhiteSpace($ExpectedTargetHash) -or
                -not [string]::Equals($currentHash, $ExpectedTargetHash,
                    [StringComparison]::OrdinalIgnoreCase)) {
                throw "$Name changed during staging preparation; refusing file drift."
            }
        }
        if ($EnforceTargetDirectorySnapshot) {
            $expectedAfterStaging = @(
                @($ExpectedTargetDirectoryNames) + (Split-Path $StagingPath -Leaf)
            )
            & $assertDirectoryNames `
                $expectedAfterStaging `
                'during staging preparation'
        }
        Move-Item -LiteralPath $StagingPath -Destination $TargetPath -Force
        $stepState.TargetPublished = $true
        $stepState.PublishedHash = $preparedHash
        if (-not [string]::Equals(
            (Get-FileHash -LiteralPath $TargetPath -Algorithm SHA256).Hash,
            $preparedHash,
            [StringComparison]::OrdinalIgnoreCase)) {
            throw "$Name changed during installer publication; refusing to continue."
        }
        if ($EnforceTargetDirectorySnapshot) {
            $expectedAfterPublish = @($ExpectedTargetDirectoryNames)
            if (-not $TargetExisted) {
                $expectedAfterPublish += (Split-Path $TargetPath -Leaf)
            }
            & $assertDirectoryNames `
                $expectedAfterPublish `
                'during publication'
        }
        & $AfterPublish
    }.GetNewClosure()
    $rollback = {
        if (Test-Path -LiteralPath $StagingPath -PathType Leaf) {
            Remove-Item -LiteralPath $StagingPath -Force
        }
        if ($stepState.TargetPublished) {
            if (-not (Test-Path -LiteralPath $TargetPath -PathType Leaf) -or
                -not [string]::Equals(
                    (Get-FileHash -LiteralPath $TargetPath -Algorithm SHA256).Hash,
                    $stepState.PublishedHash,
                    [StringComparison]::OrdinalIgnoreCase)) {
                throw "$Name changed after installer write; refusing stale rollback."
            }
        }
        if ($stepState.TargetPublished -and $TargetExisted -and
            (Test-Path -LiteralPath $BackupPath -PathType Leaf)) {
            Copy-Item -LiteralPath $BackupPath -Destination $TargetPath -Force
        }
        elseif ($stepState.TargetPublished -and -not $TargetExisted -and
            (Test-Path -LiteralPath $TargetPath -PathType Leaf)) {
            Remove-Item -LiteralPath $TargetPath -Force
        }
    }.GetNewClosure()
    New-LineageTransactionStep -Name $Name -Apply $apply -Rollback $rollback
}

function New-LineageOwnedFileRemovalStep {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Name,

        [Parameter(Mandatory = $true)]
        [object[]]$FileSnapshots
    )

    $snapshots = @($FileSnapshots)
    $removedSnapshots = [Collections.Generic.List[object]]::new()
    $assertLeafOrMissing = ${function:Assert-LineageLeafOrMissing}
    $assertDirectorySafe = ${function:Assert-LineageDirectorySafeOrMissing}
    $assertSnapshot = {
        param([object]$Snapshot, [string]$Phase)
        foreach ($propertyName in @('Path', 'BackupPath', 'Hash')) {
            if ($null -eq $Snapshot.PSObject.Properties[$propertyName] -or
                [string]::IsNullOrWhiteSpace([string]$Snapshot.$propertyName)) {
                throw "$Name has an invalid owned-file snapshot ($propertyName)."
            }
        }
        & $assertLeafOrMissing -Path ([string]$Snapshot.Path) -Label $Name
        if (-not (Test-Path -LiteralPath $Snapshot.Path -PathType Leaf)) {
            throw "$Name changed $Phase; refusing file drift."
        }
        $currentHash = (Get-FileHash -LiteralPath $Snapshot.Path -Algorithm SHA256).Hash
        if (-not [string]::Equals(
            $currentHash,
            [string]$Snapshot.Hash,
            [StringComparison]::OrdinalIgnoreCase)) {
            throw "$Name changed $Phase; refusing file drift."
        }
        if (-not (Test-Path -LiteralPath $Snapshot.BackupPath -PathType Leaf) -or
            -not [string]::Equals(
                (Get-FileHash -LiteralPath $Snapshot.BackupPath -Algorithm SHA256).Hash,
                [string]$Snapshot.Hash,
                [StringComparison]::OrdinalIgnoreCase)) {
            throw "$Name recovery backup is missing or invalid."
        }
    }.GetNewClosure()
    $apply = {
        foreach ($snapshot in $snapshots) {
            & $assertSnapshot $snapshot 'after uninstall preflight'
        }
        foreach ($snapshot in $snapshots) {
            & $assertSnapshot $snapshot 'during uninstall removal'
            Remove-Item -LiteralPath $snapshot.Path -Force
            if (Test-Path -LiteralPath $snapshot.Path) {
                throw "$Name could not remove the owned file: $($snapshot.Path)"
            }
            $removedSnapshots.Add($snapshot)
        }
    }.GetNewClosure()
    $rollback = {
        for ($index = $removedSnapshots.Count - 1; $index -ge 0; $index--) {
            $snapshot = $removedSnapshots[$index]
            if (Test-Path -LiteralPath $snapshot.Path) {
                throw "$Name changed after uninstall write; refusing stale rollback."
            }
            if (-not (Test-Path -LiteralPath $snapshot.BackupPath -PathType Leaf) -or
                -not [string]::Equals(
                    (Get-FileHash -LiteralPath $snapshot.BackupPath -Algorithm SHA256).Hash,
                    [string]$snapshot.Hash,
                [StringComparison]::OrdinalIgnoreCase)) {
                throw "$Name recovery backup changed; refusing stale rollback."
            }
            $targetDirectory = Split-Path $snapshot.Path -Parent
            & $assertDirectorySafe -Path $targetDirectory -Label "$Name restore directory"
            if (-not (Test-Path -LiteralPath $targetDirectory -PathType Container)) {
                [void](New-Item -ItemType Directory -Path $targetDirectory)
            }
            Copy-Item -LiteralPath $snapshot.BackupPath -Destination $snapshot.Path
            if (-not [string]::Equals(
                (Get-FileHash -LiteralPath $snapshot.Path -Algorithm SHA256).Hash,
                [string]$snapshot.Hash,
                [StringComparison]::OrdinalIgnoreCase)) {
                throw "$Name recovery restore failed hash verification."
            }
        }
    }.GetNewClosure()
    New-LineageTransactionStep -Name $Name -Apply $apply -Rollback $rollback
}

function Assert-LineagePackageOutputTypes {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$OutputPath,
        [Parameter(Mandatory = $true)]
        [string]$ZipPath
    )

    if ((Test-Path -LiteralPath $OutputPath) -and
        -not (Test-Path -LiteralPath $OutputPath -PathType Container)) {
        throw "The package output must be a directory when it exists: $OutputPath"
    }
    if ((Test-Path -LiteralPath $ZipPath) -and
        -not (Test-Path -LiteralPath $ZipPath -PathType Leaf)) {
        throw "The package archive must be a file when it exists: $ZipPath"
    }
}

function Invoke-LineageCleanupPreservingPrimaryError {
    [CmdletBinding()]
    param(
        [AllowNull()]
        [System.Management.Automation.ErrorRecord]$PrimaryError,

        [AllowEmptyCollection()]
        [object[]]$CleanupActions
    )

    $cleanupErrors = [System.Collections.Generic.List[string]]::new()
    foreach ($cleanup in @($CleanupActions)) {
        try {
            & $cleanup.Action
        }
        catch {
            $cleanupErrors.Add("$($cleanup.Label): $($_.Exception.Message)")
        }
    }

    if ($null -ne $PrimaryError) {
        if ($cleanupErrors.Count -eq 0) {
            throw $PrimaryError
        }
        $message = "Original error: $($PrimaryError.Exception.Message) Cleanup errors: $([string]::Join('; ', $cleanupErrors))"
        throw [InvalidOperationException]::new($message, $PrimaryError.Exception)
    }
    if ($cleanupErrors.Count -gt 0) {
        throw [InvalidOperationException]::new(
            "Package cleanup failed: $([string]::Join('; ', $cleanupErrors))")
    }
}

function Invoke-LineagePackagePublication {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$StagingPath,
        [Parameter(Mandatory = $true)]
        [string]$OutputPath,
        [Parameter(Mandatory = $true)]
        [string]$StagingZipPath,
        [Parameter(Mandatory = $true)]
        [string]$ZipPath,
        [Parameter(Mandatory = $true)]
        [string]$BackupPath,
        [Parameter(Mandatory = $true)]
        [string]$BackupZipPath,
        [scriptblock]$FailureInjector = { param($Boundary) },
        [scriptblock]$RollbackFailureInjector = { param($Boundary) }
    )

    Assert-LineagePackageOutputTypes -OutputPath $OutputPath -ZipPath $ZipPath
    foreach ($directory in @(
        [pscustomobject]@{ Path = $StagingPath; Label = 'The staged package directory' },
        [pscustomobject]@{ Path = $OutputPath; Label = 'The package output directory' },
        [pscustomobject]@{ Path = $BackupPath; Label = 'The package backup directory' }
    )) {
        Assert-LineageDirectorySafeOrMissing -Path $directory.Path -Label $directory.Label
    }
    foreach ($file in @(
        [pscustomobject]@{ Path = $StagingZipPath; Label = 'The staged package archive' },
        [pscustomobject]@{ Path = $ZipPath; Label = 'The package archive' },
        [pscustomobject]@{ Path = $BackupZipPath; Label = 'The package archive backup' }
    )) {
        Assert-LineageLeafOrMissing -Path $file.Path -Label $file.Label
    }
    if (-not (Test-Path -LiteralPath $StagingPath -PathType Container)) {
        throw "The staged package directory is missing: $StagingPath"
    }
    if (-not (Test-Path -LiteralPath $StagingZipPath -PathType Leaf)) {
        throw "The staged package archive is missing: $StagingZipPath"
    }
    if ((Test-Path -LiteralPath $BackupPath) -or
        (Test-Path -LiteralPath $BackupZipPath)) {
        throw 'A package publication backup path already exists.'
    }

    $publishedOutput = $false
    $publishedZip = $false
    $outputBackedUp = $false
    $zipBackedUp = $false
    $succeeded = $false
    $rollbackIncomplete = $false
    try {
        if (Test-Path -LiteralPath $OutputPath -PathType Container) {
            Move-Item -LiteralPath $OutputPath -Destination $BackupPath
            $outputBackedUp = $true
            & $FailureInjector 'AfterOutputBackup'
        }
        Move-Item -LiteralPath $StagingPath -Destination $OutputPath
        $publishedOutput = $true
        & $FailureInjector 'AfterOutputPublish'

        if (Test-Path -LiteralPath $ZipPath -PathType Leaf) {
            Move-Item -LiteralPath $ZipPath -Destination $BackupZipPath
            $zipBackedUp = $true
            & $FailureInjector 'AfterZipBackup'
        }
        Move-Item -LiteralPath $StagingZipPath -Destination $ZipPath
        $publishedZip = $true
        & $FailureInjector 'AfterZipPublish'
        $succeeded = $true
    }
    catch {
        $originalError = $_
        $rollbackErrors = [System.Collections.Generic.List[string]]::new()
        if ($publishedZip -and (Test-Path -LiteralPath $ZipPath -PathType Leaf)) {
            try {
                & $RollbackFailureInjector 'BeforeRemovePublishedZip'
                Remove-Item -LiteralPath $ZipPath -Force
            }
            catch { $rollbackErrors.Add("Remove published ZIP: $($_.Exception.Message)") }
        }
        if ($zipBackedUp -and (Test-Path -LiteralPath $BackupZipPath -PathType Leaf)) {
            try {
                & $RollbackFailureInjector 'BeforeRestorePreviousZip'
                Move-Item -LiteralPath $BackupZipPath -Destination $ZipPath
            }
            catch { $rollbackErrors.Add("Restore previous ZIP: $($_.Exception.Message)") }
        }
        if ($publishedOutput -and (Test-Path -LiteralPath $OutputPath -PathType Container)) {
            try {
                & $RollbackFailureInjector 'BeforeRemovePublishedOutput'
                Remove-Item -LiteralPath $OutputPath -Recurse -Force
            }
            catch { $rollbackErrors.Add("Remove published output: $($_.Exception.Message)") }
        }
        if ($outputBackedUp -and (Test-Path -LiteralPath $BackupPath -PathType Container)) {
            try {
                & $RollbackFailureInjector 'BeforeRestorePreviousOutput'
                Move-Item -LiteralPath $BackupPath -Destination $OutputPath
            }
            catch { $rollbackErrors.Add("Restore previous output: $($_.Exception.Message)") }
        }
        if ($rollbackErrors.Count -gt 0) {
            $rollbackIncomplete = $true
            $message = 'Package publication failed and rollback was incomplete. ' +
                "Original error: $($originalError.Exception.Message) " +
                "Rollback errors: $([string]::Join('; ', $rollbackErrors))"
            $exception = [InvalidOperationException]::new(
                $message,
                $originalError.Exception)
            $exception.Data['LineagePackageRollbackIncomplete'] = $true
            throw $exception
        }
        throw $originalError
    }
    finally {
        if ($succeeded -or -not $rollbackIncomplete) {
            if (Test-Path -LiteralPath $BackupZipPath -PathType Leaf) {
                Remove-Item -LiteralPath $BackupZipPath -Force
            }
            if (Test-Path -LiteralPath $BackupPath -PathType Container) {
                Remove-Item -LiteralPath $BackupPath -Recurse -Force
            }
        }
    }
}

function New-LineageTransactionStep {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string]$Name,

        [Parameter(Mandatory = $true)]
        [scriptblock]$Apply,

        [Parameter(Mandatory = $true)]
        [scriptblock]$Rollback
    )

    [pscustomobject]@{
        Name = $Name
        Apply = $Apply
        Rollback = $Rollback
    }
}

function Invoke-LineageTransaction {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [ValidateNotNull()]
        [object[]]$Steps
    )

    $startedSteps = [System.Collections.Generic.List[object]]::new()
    try {
        foreach ($step in $Steps) {
            if ($null -eq $step -or
                [string]::IsNullOrWhiteSpace([string]$step.Name) -or
                $step.Apply -isnot [scriptblock] -or
                $step.Rollback -isnot [scriptblock]) {
                throw 'Each installer transaction step must define Name, Apply, and Rollback.'
            }

            $startedSteps.Add($step)
            & $step.Apply
        }
    }
    catch {
        $originalError = $_
        $rollbackErrors = [System.Collections.Generic.List[string]]::new()
        for ($index = $startedSteps.Count - 1; $index -ge 0; $index--) {
            $step = $startedSteps[$index]
            try {
                & $step.Rollback
            }
            catch {
                $rollbackErrors.Add("$($step.Name): $($_.Exception.Message)")
            }
        }

        if ($rollbackErrors.Count -gt 0) {
            $message = 'Lineage installation failed and rollback was incomplete. ' +
                "Original error: $($originalError.Exception.Message) " +
                "Rollback errors: $([string]::Join('; ', $rollbackErrors))"
            $exception = [InvalidOperationException]::new($message, $originalError.Exception)
            $exception.Data['LineageRollbackIncomplete'] = $true
            throw $exception
        }

        throw $originalError
    }
}
