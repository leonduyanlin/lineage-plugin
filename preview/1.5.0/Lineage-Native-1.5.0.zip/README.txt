UNSIGNED PREVIEW - TRUSTED TESTERS ONLY
Lineage Native Excel Add-in 1.5.0

Install this unsigned preview:
1. Close every Excel window.
2. Download the ZIP, versioned preview bootstrap, and SHA256SUMS.txt from
   https://github.com/leonduyanlin/lineage-plugin only.
3. Compare the ZIP SHA-256 with SHA256SUMS.txt through the official release page.
4. Unblock only the downloaded preview bootstrap, then run it with ZipPath,
   ChecksumsPath, and -AcceptUnsignedPreviewRisk. Never override the execution policy.

This preview is not code-signed and Windows cannot verify its publisher. It cannot
replace an existing signed production installation. Signed production releases
instead use the separately distributed signed bootstrap described below.

The installer verifies the packaged XLL against manifest.sha256 and rolls back
file, trust-location, registration, and receipt changes if installation fails.
The uninstaller also rolls back partial registry or file removal on failure.
It removes only the exact receipt-owned Excel OPEN registration and unchanged
Lineage trusted-location values; unrelated or later-modified registry state is
left in place. Conflicting file targets or trusted-location values are rejected
before installation changes the machine.

Shortcuts:
- Ctrl+Shift+[ traces precedents.
- Ctrl+Shift+] traces dependents.
- Circular Calculations and Formula Map remain available from the Ribbon.
- Lineage does not register or intercept any other keyboard shortcut.

Ribbon:
- Trace contains Trace Precedents and Trace Dependents as large commands.
- Formula Check and Formula Map are large Audit commands; Clean Workbook is a large Publish command.
- Settings contains Circular Calculations, Show Lineage, and Lineage Settings as small commands, in that order.
- Copy Sum, Replace Formulas, Paste Inner Refs, and Paste Exact Copy are merged into Build; there is no Replication group.
- Trace, Audit, Build, Format, Publish, and Settings contain the retained tools only.
- All controls use native Excel command icons. Formula Map uses Color Scales;
  Single Page Break uses Print;
  Horizontal Check uses Evaluate Formula; IFERROR Wrap uses Trace Error;
  Insert CAGR uses Trendline; and Switch Sign uses Minus.

Auto-Color, Wrap IFERROR, Switch Sign, AutoFit, Center Across, and other direct
background commands finish without opening the main Trace pane. Formula Map is
reversible and preserves unrelated conditional formatting.
Remove Page Breaks runs in the background, resets manual breaks, and hides both
manual and automatic page-break indicators on the active worksheet. It cannot
be undone, so it clears any older pending Lineage undo entry after success.
Single Page Break preserves the current print area, fits it to one page wide by
one page tall, removes manual breaks that would force extra printed pages, and
provides exact one-level undo for the page settings and removed manual breaks.

Use Lineage > Lineage Settings to manage Formula Map and Auto Color palettes. Shortcut and Ribbon
visibility/capability settings are not exposed in the Lineage Settings dialog.
Excel Undo exposes one Lineage action at a time: this is a one-level undo for the
most recent eligible Lineage command, not a replacement for Excel's history.
Clean Workbook and Prepare Workbook always operate on a separately created copy.

The add-in runs inside Excel and does not require a local server, Node.js, or an internet connection.
Use the versioned preview bootstrap with Action=Uninstall and -AcceptUnsignedPreviewRisk to remove it.
