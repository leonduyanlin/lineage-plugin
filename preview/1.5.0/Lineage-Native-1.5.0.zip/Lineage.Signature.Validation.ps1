Set-StrictMode -Version 2.0

function ConvertTo-LineageSignerThumbprint {
    [CmdletBinding()]
    param(
        [AllowNull()]
        [string]$Thumbprint
    )

    if ([string]::IsNullOrWhiteSpace($Thumbprint)) {
        return ''
    }
    return ([regex]::Replace($Thumbprint, '[^0-9A-Fa-f]', '')).ToUpperInvariant()
}

function Assert-LineageAuthenticodeSignature {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,

        [Parameter(Mandatory = $true)]
        [string]$ExpectedThumbprint,

        [scriptblock]$SignatureProvider = {
            param([string]$SignaturePath)
            Get-AuthenticodeSignature -LiteralPath $SignaturePath
        }
    )

    $resolvedPath = [IO.Path]::GetFullPath($Path)
    if (-not (Test-Path -LiteralPath $resolvedPath -PathType Leaf)) {
        throw "The signed Lineage file is missing: $resolvedPath"
    }
    $expected = ConvertTo-LineageSignerThumbprint -Thumbprint $ExpectedThumbprint
    if ([string]::IsNullOrWhiteSpace($expected)) {
        throw 'A pinned Lineage signer thumbprint is required.'
    }

    $signature = & $SignatureProvider $resolvedPath
    if ($null -eq $signature) {
        throw "No Authenticode result was returned for $resolvedPath."
    }
    if ([string]$signature.Status -ne 'Valid') {
        throw "The Authenticode signature is not valid for $resolvedPath. Status=$($signature.Status) Message=$($signature.StatusMessage)"
    }
    if ($null -eq $signature.SignerCertificate) {
        throw "The Authenticode signature has no signer certificate for $resolvedPath."
    }

    $actual = ConvertTo-LineageSignerThumbprint `
        -Thumbprint ([string]$signature.SignerCertificate.Thumbprint)
    if (-not [string]::Equals($actual, $expected, [StringComparison]::Ordinal)) {
        throw "The Authenticode signer for $resolvedPath is not the pinned Lineage signer. Expected=$expected Actual=$actual"
    }

    [pscustomobject]@{
        Path = $resolvedPath
        Thumbprint = $actual
        Status = 'Valid'
    }
}
